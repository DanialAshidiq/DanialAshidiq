# User Guide for ICT2102 HR Mobile Application Team 17

**User Installation Instructions**:

1.Install APK given on Emulator/Device
- Recommended device/screen size(Emulator):  Pixel 4a (5.8’, 1080x2340)
- Launch emulator
- Drag apk file into emulator

If unable to install APK on Emulator/Device:

2.Run project on Android Studio - required to change sdk directory
- Edit local.properties
- sdk.dir=/Users/suhaili/Library/Android/sdk to <Location of SDK>
- SDK location can be found in Tools > SDK Manager.

![This is an image](https://res.cloudinary.com/duyks4xux/image/upload/v1636888871/Capture_amvccr.jpg)

If both methods didn’t work, view screen recording in the user guide directory folder.


**Account Details**:
Manager Account: (Contains Manager View - Approve/Reject Leaves)

Employee ID: manager
  
  
Password: 123


Staff Account:
  
  
Employee ID: staff1 

  
Password: 123


Employee ID: staff2 
  

Password: 123

**QR Code Location Test**:
  
Choa Chu Kang:
  
  
![This is an image](https://res.cloudinary.com/duyks4xux/image/upload/c_scale,h_200/v1638611411/cck_iz9mpv.jpg)


Tampines:

![This is an image](https://res.cloudinary.com/duyks4xux/image/upload/c_scale,h_200/v1638611411/tampines_uf3qxt.jpg)
