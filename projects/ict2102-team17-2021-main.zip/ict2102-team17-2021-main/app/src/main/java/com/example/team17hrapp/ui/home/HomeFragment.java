package com.example.team17hrapp.ui.home;

import static android.content.Context.MODE_PRIVATE;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.example.team17hrapp.Attendance;
import com.example.team17hrapp.AttendanceActivity;
import com.example.team17hrapp.CompareActivity;
import com.example.team17hrapp.InitialActivity;
import com.example.team17hrapp.Leave;
import com.example.team17hrapp.LeavesActivity;
import com.example.team17hrapp.LeavesActivity2;
import com.example.team17hrapp.MainActivity;
import com.example.team17hrapp.PendingLeavesActivity;
import com.example.team17hrapp.R;
import com.example.team17hrapp.databinding.FragmentHomeBinding;
import com.example.team17hrapp.ui.LeaveList.LeaveListFragment;
import com.example.team17hrapp.ui.profile.ProfileFragment;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class HomeFragment extends Fragment {

    private HomeViewModel homeViewModel;
    private FragmentHomeBinding binding;
    ArrayList<Attendance> attend = new ArrayList<Attendance>();
    ArrayList<Leave> leave = new ArrayList<Leave>();
    ArrayList<String> roleList = new ArrayList<String>();
    ArrayList<Leave> leaveALL = new ArrayList<Leave>();
    ArrayList<String> nameList = new ArrayList<String>();
    ArrayList<Boolean> atList = new ArrayList<Boolean>();
    String uid;



    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        homeViewModel =
                new ViewModelProvider(this).get(HomeViewModel.class);

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();



        SharedPreferences sh = getActivity().getSharedPreferences("USERDETAILS", MODE_PRIVATE);
        String uid = sh.getString("UID", "");

        SharedPreferences sharedPreferences = this.getActivity().getSharedPreferences("USERDETAILS", MODE_PRIVATE);
        String value = sharedPreferences.getString("JSON", "");
        try {
            JSONArray arr = new JSONArray(value);
            for(int i=0; i<arr.length(); i++)
            {
                JSONObject obj = arr.getJSONObject(i);
                if(obj.getString("userid").equals(uid))
                {
                    JSONArray arrL = obj.getJSONArray("leave");
                    String name = obj.getString("name");
                    JSONObject attObj = arrL.getJSONObject(arr.length()-1);
                    String type = attObj.getString("name");
                    String sDate = attObj.getString("start_date");
                    String eDate = attObj.getString("end_date");
                    String com = attObj.getString("comments");
                    Leave l = new Leave(name,type,"Pending",sDate,eDate,com);
                    leave.add(l);
                    JSONArray arrA = obj.getJSONArray("Attendance");
                    JSONObject attObjA = arrA.getJSONObject(0);
                    String loc = attObjA.getString("location"); //change to attendance object
                    Boolean att = attObjA.getBoolean("isAttendance");
                    String time = attObjA.getString("time");
                    Attendance a = new Attendance(loc,att,time);
                    attend.add(a);


                }
            }
        } catch (Exception e) {

        }

//        attend = get_Attendance(uid);
//        leave = get_Leave(uid);
//
//
        final TextView tvAttendance = binding.textViewAttendance;
        final TextView tvLeave = binding.textViewLeave;
        final TextView tvDate = binding.textViewDate;

        if (attend.get(0).getAttendance().equals(false)){
            tvAttendance.setText("Check In: - ");
        }else{
            tvAttendance.setText("Check In: " + attend.get(0).getCheckInTime());
        }

        tvLeave.setText(leave.get(0).getType());
        tvDate.setText(leave.get(0).getStartDate() + "-" + leave.get(0).getEndDate());

        //BOTTOM LEAVE
        final TextView tvBType = binding.tvLeaveType;
        final TextView tvBStart = binding.tvStartDate;
        final TextView tvBEnd = binding.tvEndDate;
        final TextView tvBStatus = binding.tvStatus;

        tvBType.setText(leave.get(0).getType());
        tvBStart.setText("From: "+leave.get(0).getStartDate());
        tvBEnd.setText("Until: "+leave.get(0).getEndDate());
        tvBStatus.setText(leave.get(0).getStatus());

        //check role then display approve/deny tab set visibility



        final LinearLayout attendancell = binding.linearLayout;
        final LinearLayout leavell = binding.llLeaves;
        final LinearLayout meeting = binding.linearLayout4;
        final LinearLayout onleavell = binding.linearLayout7;

        atList = get_Attendance(uid);
        attendancell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(atList.size() != 0){
                    if (atList.get(0).equals(false)){
                        Navigation.findNavController(v).navigate(R.id.action_navigation_home_to_navigation_attendance);
                    }else{
                        Navigation.findNavController(v).navigate(R.id.action_navigation_home_to_navigation_checkout);
                    }
                }else{
                    Navigation.findNavController(v).navigate(R.id.action_navigation_home_to_navigation_attendance);
                }
            }
        });

        leavell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Navigation.findNavController(v).navigate(R.id.action_navigation_home_to_navigation_leaveList);
            }
        });

        meeting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Navigation.findNavController(v).navigate(R.id.action_navigation_home_to_navigation_calendar);
            }
        });

        onleavell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Navigation.findNavController(v).navigate(R.id.action_navigation_home_to_navigation_compare);

            }
        });


//        final TextView textView = binding.textHome;
        final ImageButton ib = binding.imageButton11;
        ib.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Navigation.findNavController(v).navigate(R.id.action_navigation_home_to_navigation_leaveList);

            }
        });

        final LinearLayout llManager = binding.llManager;

        roleList = getRole(uid);

        String role = roleList.get(0).toString();
        if (role.equals("admin")){
            llManager.setVisibility(View.VISIBLE);
        }

        //leave approval
        final TextView tvDetails = binding.tvLeaveApproveName;
        final TextView tvSDate = binding.tvStartDateAppr;
        final TextView tvEDate = binding.tvEndDateAppr;
        final Button btnApprove = binding.buttonApprove;
        final Button btnReject = binding.buttonReject;

        btnApprove.setTextColor(Color.parseColor("#FFFFFF"));
        btnApprove.setBackgroundColor(Color.parseColor("#167F39"));

        btnReject.setTextColor(Color.parseColor("#FFFFFF"));
        btnReject.setBackgroundColor(Color.parseColor("#DF0000"));
        final ImageButton btnMoreApprove = binding.moreApproveLeaves;

        leaveALL = getLatestDetails();
        nameList = getNameList();

        if (leaveALL.size()!= 0) {
            Leave lastLeave = leaveALL.get(leaveALL.size() - 1);
            if (leaveALL.size() != 0) {
                Log.d("LEAVE ALL SIZE", leaveALL.size() + "");
                tvDetails.setText(nameList.get(nameList.size() - 1).toString() + ": " + lastLeave.getType());
                tvSDate.setText("From: " + lastLeave.getStartDate());
                tvEDate.setText("Until: " + lastLeave.getEndDate());
            } else {
                llManager.setVisibility(View.GONE);

            }


        btnApprove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder1 = new AlertDialog.Builder(getActivity());
                builder1.setMessage("Confirm Approval?");
                builder1.setCancelable(false);

                builder1.setPositiveButton(
                        "Cancel",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
                builder1.setNeutralButton(
                        "Approve",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                approveLeave(nameList.get(nameList.size()-1).toString(),lastLeave.getStartDate(),lastLeave.getEndDate());
                                Navigation.findNavController(v).navigate(R.id.navigation_home);

                            }
                        });

                AlertDialog alert11 = builder1.create();
                alert11.show();

            }
        });

            btnReject.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AlertDialog.Builder builder1 = new AlertDialog.Builder(getActivity());
                    builder1.setMessage("Confirm Rejection?");
                    builder1.setCancelable(false);

                    builder1.setPositiveButton(
                            "Cancel",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                }
                            });
                    builder1.setNeutralButton(
                            "Reject",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    rejectLeave(nameList.get(nameList.size()-1).toString(),lastLeave.getStartDate(),lastLeave.getEndDate());
                                    Navigation.findNavController(v).navigate(R.id.navigation_home);
                                }
                            });

                    AlertDialog alert11 = builder1.create();
                    alert11.show();
                }
            });

            }else{
            btnApprove.setVisibility(View.GONE);
            btnReject.setVisibility(View.GONE);
            tvDetails.setText("No leaves needed to be approve");
            tvSDate.setVisibility(View.GONE);
            tvEDate.setVisibility(View.GONE);
        }

        final ImageButton pendingbtn = binding.moreApproveLeaves;

        pendingbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Navigation.findNavController(v).navigate(R.id.action_navigation_home_to_navigation_pendingList);
            }
        });






//        homeViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
//            @Override
//            public void onChanged(@Nullable String s) {
//                textView.setText(s);
//            }
//        });
        return root;
    }



    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    public ArrayList<String> getRole(String uid) {
        SharedPreferences sharedPreferences = this.getActivity().getSharedPreferences("USERDETAILS", MODE_PRIVATE);
        String value = sharedPreferences.getString("JSON", "");
        try {
            JSONArray arr = new JSONArray(value);
            for(int i=0; i<arr.length(); i++)
            {
                JSONObject obj = arr.getJSONObject(i);
                if(obj.getString("userid").equals(uid))
                {
                    String name = obj.getString("role");
                    roleList.add(name);


                }
            }
        } catch (Exception e) {

        }
        return roleList;
    }

    public ArrayList<Leave> getLatestDetails() {
        SharedPreferences sharedPreferences = this.getActivity().getSharedPreferences("USERDETAILS", MODE_PRIVATE);
        String value = sharedPreferences.getString("JSON", "");
        try {
            JSONArray arr = new JSONArray(value);
//            for(int i=0; i<arr.length(); i++)
//            {
                JSONObject obj = arr.getJSONObject(arr.length()-1);
                String name = obj.getString("name");
                JSONArray leavesArr = obj.getJSONArray("leave");
                for(int j=0; j<arr.length(); j++) {
                    JSONObject leaveObj = leavesArr.getJSONObject(j);
                    String type = leaveObj.getString("name");
                    String status = leaveObj.getString("status");
                    String startDate = leaveObj.getString("start_date");
                    String endDate = leaveObj.getString("end_date");
                    String days = leaveObj.getString("days");
                    Log.d("status", status);
                    if (status.equals("Pending")) {
                        Leave a = new Leave(name, type, status, startDate, endDate, days);
                        leaveALL.add(a);
                    }
                }
//            }
        } catch (Exception e) {

        }
        return leaveALL;
    }

    public ArrayList<String> getNameList() {
        SharedPreferences sharedPreferences = this.getActivity().getSharedPreferences("USERDETAILS", MODE_PRIVATE);
        String value = sharedPreferences.getString("JSON", "");
        try {
            JSONArray arr = new JSONArray(value);
            for(int i=0; i<arr.length(); i++)
            {
                JSONObject obj = arr.getJSONObject(i);
                String name = obj.getString("name");
                nameList.add(name);
            }
        } catch (Exception e) {

        }
        return nameList;
    }

    public void approveLeave(String name, String sDate, String eDate) {
        SharedPreferences sharedPreferences = this.getActivity().getSharedPreferences("USERDETAILS", MODE_PRIVATE);
        String value = sharedPreferences.getString("JSON", "");
        try {
            JSONArray arr = new JSONArray(value);
            for(int i=0; i<arr.length(); i++)
            {
                JSONObject obj = arr.getJSONObject(i);
                String nameO = obj.getString("name");
                if (nameO.equals(name)){
                    JSONArray leavesArr = obj.getJSONArray("leave");
                    for(int j=0; j<arr.length(); j++) {
                        JSONObject leaveObj = leavesArr.getJSONObject(j);
                        String startDate = leaveObj.getString("start_date");
                        String endDate = leaveObj.getString("end_date");
                        if (startDate.equals(sDate) && endDate.equals(eDate)){
                            leaveObj.put("status","Approved");
                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            editor.putString("JSON", arr.toString()).commit();
                        }
                    }
                }
            }
        } catch (Exception e) {

        }

    }

    public void rejectLeave(String name, String sDate, String eDate) {
        SharedPreferences sharedPreferences = this.getActivity().getSharedPreferences("USERDETAILS", MODE_PRIVATE);
        String value = sharedPreferences.getString("JSON", "");
        try {
            JSONArray arr = new JSONArray(value);
            for(int i=0; i<arr.length(); i++)
            {
                JSONObject obj = arr.getJSONObject(i);
                String nameO = obj.getString("name");
                if (nameO.equals(name)){
                    JSONArray leavesArr = obj.getJSONArray("leave");
                    for(int j=0; j<arr.length(); j++) {
                        JSONObject leaveObj = leavesArr.getJSONObject(j);
                        String startDate = leaveObj.getString("start_date");
                        String endDate = leaveObj.getString("end_date");
                        if (startDate.equals(sDate) && endDate.equals(eDate)){
                            leaveObj.put("status","Rejected");
                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            editor.putString("JSON", arr.toString()).commit();
                        }
                    }
                }
            }
        } catch (Exception e) {

        }

    }

    public ArrayList<Boolean> get_Attendance(String uid) {
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("USERDETAILS", MODE_PRIVATE);
        String value = sharedPreferences.getString("JSON", "");
        try {
            JSONArray arr = new JSONArray(value);
            for(int i=0; i<arr.length(); i++)
            {
                JSONObject obj = arr.getJSONObject(i);
                if(obj.getString("userid").equals(uid))
                {
                    JSONArray arrA = obj.getJSONArray("Attendance");
                    JSONObject attObjA = arrA.getJSONObject(0);
                    Boolean att = attObjA.getBoolean("isAttendance");
                    atList.add(att);
                }
            }
        } catch (Exception e) {

        }
        return atList;

    }


}

