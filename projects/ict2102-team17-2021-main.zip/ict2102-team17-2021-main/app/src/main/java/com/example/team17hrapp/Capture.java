package com.example.team17hrapp;

import com.journeyapps.barcodescanner.CaptureActivity;

public class Capture extends CaptureActivity {
}
