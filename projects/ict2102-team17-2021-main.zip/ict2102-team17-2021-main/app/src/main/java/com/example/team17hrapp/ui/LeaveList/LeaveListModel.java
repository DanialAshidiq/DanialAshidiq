package com.example.team17hrapp.ui.LeaveList;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class LeaveListModel extends ViewModel {
    private MutableLiveData<String> mText;

    public LeaveListModel() {
        mText = new MutableLiveData<>();
        mText.setValue("LIST OF LEAVES PAGE");
    }

    public LiveData<String> getText() {
        return mText;
    }

}
