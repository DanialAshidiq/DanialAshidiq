package com.example.team17hrapp.ui.notifications;

import static android.content.Context.MODE_PRIVATE;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.applandeo.materialcalendarview.EventDay;
import com.example.team17hrapp.InitialActivity;
import com.example.team17hrapp.databinding.FragmentNotificationsBinding;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class NotificationsFragment extends Fragment {

    private NotificationsViewModel notificationsViewModel;
    private FragmentNotificationsBinding binding;
    ArrayList<String> name = new ArrayList<>();
    ArrayList<String> attendance = new ArrayList<>();


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        notificationsViewModel =
                new ViewModelProvider(this).get(NotificationsViewModel.class);

        binding = FragmentNotificationsBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        SharedPreferences sh = getActivity().getSharedPreferences("USERDETAILS", MODE_PRIVATE);
        String uid = sh.getString("UID", "");

        final TextView tvName = binding.tvProfileName;
        final TextView tvAtt = binding.tvProfileAtt;

        name = getName(uid);
        attendance = getAtt(uid);

        tvName.setText(name.get(0));
        tvAtt.setText(attendance.get(0));

        final Button signout = binding.button2;

        signout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent a = new Intent(getActivity(), InitialActivity.class);
                startActivity(a);
            }
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    public ArrayList<String> getName(String uid) {
        SharedPreferences sharedPreferences = this.getActivity().getSharedPreferences("USERDETAILS", MODE_PRIVATE);
        String value = sharedPreferences.getString("JSON", "");
        try {
            JSONArray arr = new JSONArray(value);
            for(int i=0; i<arr.length(); i++)
            {
                JSONObject obj = arr.getJSONObject(i);
                if(obj.getString("userid").equals(uid))
                {
                    String nameUser = obj.getString("name");
                    name.add(nameUser);

                }
            }
        } catch (Exception e) {

        }
        return name;
    }

    public ArrayList<String> getAtt(String uid) {
        SharedPreferences sharedPreferences = this.getActivity().getSharedPreferences("USERDETAILS", MODE_PRIVATE);
        String value = sharedPreferences.getString("JSON", "");
        try {
            JSONArray arr = new JSONArray(value);
            for(int i=0; i<arr.length(); i++)
            {
                JSONObject obj = arr.getJSONObject(i);
                if(obj.getString("userid").equals(uid))
                {
                    JSONArray a = obj.getJSONArray("Attendance");
                    JSONObject att = a.getJSONObject(0);
                    boolean attend = att.getBoolean("isAttendance");
                    String location = att.getString("location");
                    if (attend == true){
                        attendance.add("Checked in: "+location);
                    }else{
                        attendance.add("Have not checked in!");
                    }

                }
            }
        } catch (Exception e) {

        }
        return attendance;
    }
}