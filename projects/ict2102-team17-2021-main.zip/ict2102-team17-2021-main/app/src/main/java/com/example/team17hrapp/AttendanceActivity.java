package com.example.team17hrapp;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class AttendanceActivity extends AppCompatActivity {

    ArrayList<Boolean> atList = new ArrayList<Boolean>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.attendance_activity);
        SharedPreferences sh = getSharedPreferences("USERDETAILS", MODE_PRIVATE);
        String uid = sh.getString("UID", "");
        atList = get_Attendance(uid);



        BottomNavigationView navView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_calendar, R.id.navigation_applyleave,R.id.navigation_home,R.id.navigation_scanqr, R.id.navigation_notifications)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_activity_main);

        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(navView, navController);

        navView.setSelectedItemId(R.id.navigation_scanqr);
        //check if logged in here, if in show check out page.else check in page.
        if(atList.size() != 0){
            Log.d("Attendance CHECK", atList.get(0).toString());
            if (atList.get(0).equals(false)){
                navController.navigate(R.id.navigation_attendance);
            }else{
                navController.navigate(R.id.navigation_checkout);
            }
        }else{
            navController.navigate(R.id.navigation_attendance);
        }


//        navView.getMenu().getItem(2).setCheckable(false); // unselect the default home navbar icon


    }

    public ArrayList<Boolean> get_Attendance(String uid) {
        SharedPreferences sharedPreferences = this.getApplicationContext().getSharedPreferences("USERDETAILS", MODE_PRIVATE);
        String value = sharedPreferences.getString("JSON", "");
        try {
            JSONArray arr = new JSONArray(value);
            for(int i=0; i<arr.length(); i++)
            {
                JSONObject obj = arr.getJSONObject(i);
                if(obj.getString("userid").equals(uid))
                {
                    JSONArray arrA = obj.getJSONArray("Attendance");
                    JSONObject attObjA = arrA.getJSONObject(0);
                    Boolean att = attObjA.getBoolean("isAttendance");
                    atList.add(att);
                }
            }
        } catch (Exception e) {

        }
//        String json = null;
//        try {
//            InputStream is = this.getApplicationContext().getAssets().open("data.json");
//            Log.d("test", is.toString());
//            int size = is.available();
//            byte[] buffer = new byte[size];
//            is.read(buffer);
//            is.close();
//            json = new String(buffer, "UTF-8");
//            JSONArray jsonArray = new JSONArray(json);
//            Log.d("test", "INPUT STREAM");
//
//            for (int i = 0; i < jsonArray.length(); i++) {
//                JSONObject obj = jsonArray.getJSONObject(i);
//                Log.d("test", "INSIDE LOOP");
//                if (obj.getString("userid").equals(uid)) {
//                    JSONArray attendance = obj.getJSONArray("Attendance");
//                    JSONObject attObj = attendance.getJSONObject(0);
//                    Boolean attend = attObj.getBoolean("isAttendance");
//                    atList.add(attend);
//
//                }
//            }
//
//
//        } catch (IOException e) {
//            e.printStackTrace();
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }
        return atList;


    }
}