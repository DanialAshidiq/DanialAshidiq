package com.example.team17hrapp.ui.QR;

import static android.content.Context.MODE_PRIVATE;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.example.team17hrapp.Capture;
import com.example.team17hrapp.R;
import com.example.team17hrapp.databinding.FragmentQrBinding;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class QRFragment extends Fragment {
    private QRViewModel qrViewModel;
    private FragmentQrBinding binding;
    ArrayList<Boolean> atList = new ArrayList<Boolean>();

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        qrViewModel =
                new ViewModelProvider(this).get(QRViewModel.class);

        binding = FragmentQrBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final ImageView iv = root.findViewById(R.id.imageView4);

        SharedPreferences sh = getActivity().getSharedPreferences("USERDETAILS", MODE_PRIVATE);
        String uid = sh.getString("UID", "");

        atList = get_Attendance(uid);
        if(atList.size() != 0){
            if (atList.get(0).equals(false)){
//                //no need do anything since need scan QR
                iv.setOnClickListener(new View.OnClickListener() {//replace with qr image?
                    @Override
                    public void onClick(View v) {
                        Log.d("SCANBUTTON","SCAN PRESSED");
                        IntentIntegrator intentIntegrator = new IntentIntegrator(
                                getActivity()
                        );
                        //Set prompt text
                        intentIntegrator.setPrompt("For flash use volume up key");
                        //Set beep
                        intentIntegrator.setBeepEnabled(true);
                        //Locked orientation
                        intentIntegrator.setOrientationLocked(true);
                        //Set Capture Activity
                        intentIntegrator.setCaptureActivity(Capture.class);
                        //Initiate Scan
                        intentIntegrator.initiateScan();
                        Log.d("SCANBUTTON","AFTER SCAN PRESSED");



                    }
                });
            }else{
                //navigate to check out since checked in
                Navigation.findNavController(getActivity(),R.id.nav_host_fragment_activity_main).navigate(R.id.action_navigation_scanqr_to_navigation_checkout);
            }
        }else{
            //no need do anything since scan QR
            iv.setOnClickListener(new View.OnClickListener() {//replace with qr image?
                @Override
                public void onClick(View v) {
                    Log.d("SCANBUTTON","SCAN PRESSED2");
                    IntentIntegrator intentIntegrator = new IntentIntegrator(
                            getActivity()
                    );
                    //Set prompt text
                    intentIntegrator.setPrompt("For flash use volume up key");
                    //Set beep
                    intentIntegrator.setBeepEnabled(true);
                    //Locked orientation
                    intentIntegrator.setOrientationLocked(true);
                    //Set Capture Activity
                    intentIntegrator.setCaptureActivity(Capture.class);
                    //Initiate Scan
                    intentIntegrator.initiateScan();
                    Log.d("SCANBUTTON","AFTER SCAN PRESSED2");


                }
            });
        }


        return root;
    }

    public ArrayList<Boolean> get_Attendance(String uid) {
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("USERDETAILS", MODE_PRIVATE);
        String value = sharedPreferences.getString("JSON", "");
        try {
            JSONArray arr = new JSONArray(value);
            for(int i=0; i<arr.length(); i++)
            {
                JSONObject obj = arr.getJSONObject(i);
                if(obj.getString("userid").equals(uid))
                {
                    JSONArray arrA = obj.getJSONArray("Attendance");
                    JSONObject attObjA = arrA.getJSONObject(0);
                    Boolean att = attObjA.getBoolean("isAttendance");
                    atList.add(att);
                }
            }
        } catch (Exception e) {

        }
        return atList;

    }



    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}
