package com.example.team17hrapp.ui.LeaveList;

import static android.content.Context.MODE_PRIVATE;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.example.team17hrapp.CreateActivity;
import com.example.team17hrapp.MainActivity;
import com.example.team17hrapp.CustomAdapter;
import com.example.team17hrapp.Leave;
import com.example.team17hrapp.R;
import com.example.team17hrapp.databinding.FragmentLeavelistBinding;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class LeaveListFragment extends Fragment {
    private LeaveListModel leaveViewModel;
    private FragmentLeavelistBinding binding;
    ArrayList<Leave> arrayList = new ArrayList<Leave>();




    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        leaveViewModel =
                new ViewModelProvider(this).get(LeaveListModel.class);

        binding = FragmentLeavelistBinding.inflate(inflater, container, false);
        View root = binding.getRoot();


        final ListView list = binding.list;
        final Button btn = binding.buttonCreate;
        //get Leaves function
//        ArrayList<Leave> arrayList = new ArrayList<Leave>();
//        arrayList.add(new Leave("Annual Leave","Pending","04/11/21","12/11/21","7days"));
//        arrayList.add(new Leave("Childcare Leave","Pending","02/11/21","12/11/21","10days"));
//        arrayList.add(new Leave("Maternity Leave","Pending","01/11/21","12/11/21","11days"));
//        arrayList.add(new Leave("Annual Leave","Pending","06/11/21","12/11/21","5days"));
//        arrayList.add(new Leave("Childcare Leave","Pending","11/11/21","12/11/21","1days"));
        SharedPreferences sh = getActivity().getSharedPreferences("USERDETAILS", MODE_PRIVATE);
        String uid = sh.getString("UID", "");
        arrayList = getLeaves(uid);
        CustomAdapter customAdapter = new CustomAdapter(getActivity(), arrayList);
        list.setAdapter(customAdapter);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Navigation.findNavController(v).navigate(R.id.action_navigation_leaveList_to_navigation_applyleave);
            }
        });

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Intent intent = new Intent(getActivity(), MainActivity.class);
                    startActivity(intent);

            }
        });


        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    public ArrayList<Leave> getLeaves(String uid) {
        SharedPreferences sharedPreferences = this.getActivity().getSharedPreferences("USERDETAILS", MODE_PRIVATE);
        String value = sharedPreferences.getString("JSON", "");
        try {
            JSONArray arr = new JSONArray(value);
            for(int i=0; i<arr.length(); i++)
            {
                JSONObject obj = arr.getJSONObject(i);
                if(obj.getString("userid").equals(uid))
                {
                    String name = obj.getString("name");
                    JSONArray arrA = obj.getJSONArray("leave");
                    for (int j = 0; j < arrA.length(); j++) {
                        JSONObject objLeave = arrA.getJSONObject(j);
                        if (objLeave.getString("status").equals("Pending")){
                            String type = objLeave.getString("name");
                            String sDate = objLeave.getString("start_date");
                            String eDate = objLeave.getString("end_date");
                            String days = objLeave.getString("days");
                            String status = objLeave.getString("status");
                            Leave a = new Leave(name,type,status,sDate,eDate,days);
                            arrayList.add(a);
                        }

                    }
                }
            }
        } catch (Exception e) {

        }
        return arrayList;
    }



}
