package com.example.team17hrapp;

import static android.content.Context.MODE_PRIVATE;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.DataSetObserver;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListAdapter;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class CustomAdapterPending implements ListAdapter {
    ArrayList<PendingLeave> arrayList;
    Context context;
    public CustomAdapterPending(Context context, ArrayList<PendingLeave> arrayList) {
        this.arrayList=arrayList;
        this.context=context;
    }
    @Override
    public boolean areAllItemsEnabled() {
        return false;
    }
    @Override
    public boolean isEnabled(int position) {
        return true;
    }
    @Override
    public void registerDataSetObserver(DataSetObserver observer) {
    }
    @Override
    public void unregisterDataSetObserver(DataSetObserver observer) {
    }
    @Override
    public int getCount() {
        return arrayList.size();
    }
    @Override
    public Object getItem(int position) {
        return position;
    }
    @Override
    public long getItemId(int position) {
        return position;
    }
    @Override
    public boolean hasStableIds() {
        return false;
    }

    public int convertDpToPx(Context context, float dp) {
        return (int) Math.round(dp * context.getResources().getDisplayMetrics().density);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        PendingLeave leaveData =arrayList.get(position);
        if(convertView==null) {
            LayoutInflater layoutInflater = LayoutInflater.from(context);

            convertView=layoutInflater.inflate(R.layout.pendinglist_row, null);
            TextView comment = convertView.findViewById(R.id.tvPendingComments);
            TextView name = convertView.findViewById(R.id.tvPendingName);
            TextView start = convertView.findViewById(R.id.tvPendingStartDate);
            TextView end = convertView.findViewById(R.id.tvPendingEndDate);
            ImageButton btn = convertView.findViewById(R.id.imageButton3);
            comment.setText(leaveData.getComments());
            name.setText(leaveData.getName());
            start.setText("From: "+leaveData.getStartDate());
            end.setText("Until: "+leaveData.getEndDate());
            if (position % 2 != 0)
            {
                convertView.setBackgroundColor(Color.parseColor("#FFE5B4"));
                btn.setBackgroundColor(Color.parseColor("#FFE5B4"));
            }
            convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //Dialog
                    AlertDialog.Builder builder1 = new AlertDialog.Builder(context);
                    builder1.setTitle(leaveData.getName()+"'s "+leaveData.getType());
                    builder1.setMessage("\nFrom: "+leaveData.getStartDate()+"\nUntil: "+leaveData.getEndDate()+"\n\nReason:\n"+leaveData.getComments()+"\n");
                    builder1.setCancelable(true);

                    builder1.setPositiveButton(
                            "Approve",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    AlertDialog.Builder builder1 = new AlertDialog.Builder(context);
                                    builder1.setTitle("Approve leave?");
                                    builder1.setMessage("\n"+leaveData.getName()+"\n"+leaveData.getType()+"\n\nFrom: "+leaveData.getStartDate()+"\nUntil: "+leaveData.getEndDate()+"\n");
                                    builder1.setCancelable(false);

                                    builder1.setPositiveButton(
                                            "Approve",
                                            new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int id) {
                                                    approveLeave(leaveData.getName(),leaveData.getStartDate(),leaveData.getEndDate());
                                                    Intent a = new Intent(context,PendingLeavesActivity.class);
                                                    context.startActivity(a);
                                                }
                                            });
                                    builder1.setNeutralButton(
                                            "Cancel",
                                            new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int id) {
                                                    dialog.cancel();
                                                }
                                            });

                                    AlertDialog alert11 = builder1.create();
                                    alert11.show();

                                    Button positiveButton = alert11.getButton(AlertDialog.BUTTON_POSITIVE);
                                    Button negativeButton = alert11.getButton(AlertDialog.BUTTON_NEGATIVE);
                                    Button neutralButton = alert11.getButton(AlertDialog.BUTTON_NEUTRAL);


                                    positiveButton.setTextColor(Color.parseColor("#FFFFFF"));
                                    positiveButton.setBackgroundColor(Color.parseColor("#167F39"));

                                    neutralButton.setTextColor(Color.parseColor("#FFFFFF"));
                                    neutralButton.setBackgroundColor(Color.parseColor("#DF0000"));
                                }
                            });
                    builder1.setNeutralButton(
                            "Reject",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    AlertDialog.Builder builder1 = new AlertDialog.Builder(context);
                                    builder1.setTitle("Reject leave?");
                                    builder1.setMessage("\n"+leaveData.getName()+"\n"+leaveData.getType()+"\n\nFrom: "+leaveData.getStartDate()+"\nUntil: "+leaveData.getEndDate()+"\n");
                                    builder1.setCancelable(false);

                                    builder1.setPositiveButton(
                                            "Reject",
                                            new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int id) {
                                                    rejectLeave(leaveData.getName(),leaveData.getStartDate(),leaveData.getEndDate());
                                                    Intent a = new Intent(context,PendingLeavesActivity.class);
                                                    context.startActivity(a);
                                                }
                                            });
                                    builder1.setNeutralButton(
                                            "Cancel",
                                            new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int id) {
                                                    dialog.cancel();
                                                }
                                            });

                                    AlertDialog alert11 = builder1.create();
                                    alert11.show();

                                    Button positiveButton = alert11.getButton(AlertDialog.BUTTON_POSITIVE);
                                    Button negativeButton = alert11.getButton(AlertDialog.BUTTON_NEGATIVE);
                                    Button neutralButton = alert11.getButton(AlertDialog.BUTTON_NEUTRAL);


                                    positiveButton.setTextColor(Color.parseColor("#FFFFFF"));
                                    positiveButton.setBackgroundColor(Color.parseColor("#167F39"));

                                    neutralButton.setTextColor(Color.parseColor("#FFFFFF"));
                                    neutralButton.setBackgroundColor(Color.parseColor("#DF0000"));
                                }
                            });
                    AlertDialog alert11 = builder1.create();
                    alert11.show();

                    Button positiveButton = alert11.getButton(AlertDialog.BUTTON_POSITIVE);
                    Button negativeButton = alert11.getButton(AlertDialog.BUTTON_NEGATIVE);
                    Button neutralButton = alert11.getButton(AlertDialog.BUTTON_NEUTRAL);


                    positiveButton.setTextColor(Color.parseColor("#FFFFFF"));
                    positiveButton.setBackgroundColor(Color.parseColor("#167F39"));

                    neutralButton.setTextColor(Color.parseColor("#FFFFFF"));
                    neutralButton.setBackgroundColor(Color.parseColor("#DF0000"));
                }
            });


//            type.setText(leaveData.type);
//            name.setText(leaveData.days);
//            start.setText("From: "+ leaveData.startDate);
//            end.setText("Until: "+leaveData.endDate);


        }
        return convertView;
    }
    @Override
    public int getItemViewType(int position) {
        return position;
    }
    @Override
    public int getViewTypeCount() {
        return arrayList.size();
    }
    @Override
    public boolean isEmpty() {
        return false;
    }

    public void approveLeave(String name, String sDate, String eDate) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("USERDETAILS", MODE_PRIVATE);
        String value = sharedPreferences.getString("JSON", "");
        try {
            JSONArray arr = new JSONArray(value);
            for(int i=0; i<arr.length(); i++)
            {
                JSONObject obj = arr.getJSONObject(i);
                String nameO = obj.getString("name");
                if (nameO.equals(name)){
                    JSONArray leavesArr = obj.getJSONArray("leave");
                    for(int j=0; j<arr.length(); j++) {
                        JSONObject leaveObj = leavesArr.getJSONObject(j);
                        String startDate = leaveObj.getString("start_date");
                        String endDate = leaveObj.getString("end_date");
                        if (startDate.equals(sDate) && endDate.equals(eDate)){
                            leaveObj.put("status","Approved");
                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            editor.putString("JSON", arr.toString()).commit();
                        }
                    }
                }
            }
        } catch (Exception e) {

        }

    }

    public void rejectLeave(String name, String sDate, String eDate) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("USERDETAILS", MODE_PRIVATE);
        String value = sharedPreferences.getString("JSON", "");
        try {
            JSONArray arr = new JSONArray(value);
            for(int i=0; i<arr.length(); i++)
            {
                JSONObject obj = arr.getJSONObject(i);
                String nameO = obj.getString("name");
                if (nameO.equals(name)){
                    JSONArray leavesArr = obj.getJSONArray("leave");
                    for(int j=0; j<arr.length(); j++) {
                        JSONObject leaveObj = leavesArr.getJSONObject(j);
                        String startDate = leaveObj.getString("start_date");
                        String endDate = leaveObj.getString("end_date");
                        if (startDate.equals(sDate) && endDate.equals(eDate)){
                            leaveObj.put("status","Rejected");
                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            editor.putString("JSON", arr.toString()).commit();
                        }
                    }
                }
            }
        } catch (Exception e) {

        }

    }
}