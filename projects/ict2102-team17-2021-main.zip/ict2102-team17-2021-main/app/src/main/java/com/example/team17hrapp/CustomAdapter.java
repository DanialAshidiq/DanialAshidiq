package com.example.team17hrapp;

import static android.content.Context.MODE_PRIVATE;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.DataSetObserver;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListAdapter;
import com.example.team17hrapp.Leave;
import android.widget.TextView;

import androidx.navigation.Navigation;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class CustomAdapter implements ListAdapter {
    ArrayList<Leave> arrayList;
    Context context;
    public CustomAdapter(Context context, ArrayList<Leave> arrayList) {
        this.arrayList=arrayList;
        this.context=context;
    }
    @Override
    public boolean areAllItemsEnabled() {
        return false;
    }
    @Override
    public boolean isEnabled(int position) {
        return true;
    }
    @Override
    public void registerDataSetObserver(DataSetObserver observer) {
    }
    @Override
    public void unregisterDataSetObserver(DataSetObserver observer) {
    }
    @Override
    public int getCount() {
        return arrayList.size();
    }
    @Override
    public Object getItem(int position) {
        return position;
    }
    @Override
    public long getItemId(int position) {
        return position;
    }
    @Override
    public boolean hasStableIds() {
        return false;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Leave leaveData = arrayList.get(position);
        if(convertView==null) {
            LayoutInflater layoutInflater = LayoutInflater.from(context);
            convertView=layoutInflater.inflate(R.layout.list_row, null);
            convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AlertDialog.Builder builder1 = new AlertDialog.Builder(context);
                    builder1.setTitle(leaveData.getType());
                    builder1.setMessage("\n"+leaveData.getStatus()+"\n\nFrom: "+leaveData.getStartDate()+"\nUntil: "+leaveData.getEndDate()+"\n");
                    builder1.setCancelable(false);

                    builder1.setPositiveButton(
                            "EDIT",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    arrayList.remove(position);
                                    deleteLeave(leaveData.getName(),leaveData.getStartDate(),leaveData.getEndDate());
                                    Navigation.findNavController(v).navigate(R.id.action_navigation_leaveList_to_navigation_applyleave);

                                }
                            });
                    builder1.setNeutralButton(
                            "DELETE",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    //delete function
                                    deleteLeave(leaveData.getName(),leaveData.getStartDate(),leaveData.getEndDate());
                                    Navigation.findNavController(v).navigate(R.id.action_navigation_leaveList_self);

                                }
                            });

                    AlertDialog alert11 = builder1.create();
                    alert11.show();

                    Button positiveButton = alert11.getButton(AlertDialog.BUTTON_POSITIVE);
                    Button negativeButton = alert11.getButton(AlertDialog.BUTTON_NEGATIVE);
                    Button neutralButton = alert11.getButton(AlertDialog.BUTTON_NEUTRAL);


                    positiveButton.setTextColor(Color.parseColor("#FFFFFF"));
                    positiveButton.setBackgroundColor(Color.parseColor("#167F39"));

                    neutralButton.setTextColor(Color.parseColor("#FFFFFF"));
                    neutralButton.setBackgroundColor(Color.parseColor("#DF0000"));

                }
            });
            TextView type = convertView.findViewById(R.id.tvType);
            TextView start = convertView.findViewById(R.id.tvDateStart);
            TextView end = convertView.findViewById(R.id.tvDateEnd);
            TextView days = convertView.findViewById(R.id.tvDays);
            TextView status = convertView.findViewById(R.id.tvStatus);

            type.setText(leaveData.type);
            start.setText("From: "+ leaveData.startDate);
            end.setText("Until: "+leaveData.endDate);
            days.setText(leaveData.days+ " days");
            status.setText(leaveData.status);
            if (position % 2 != 0)
            {
                convertView.setBackgroundColor(Color.parseColor("#FFE5B4"));
            }

        }
        return convertView;
    }
    @Override
    public int getItemViewType(int position) {
        return position;
    }
    @Override
    public int getViewTypeCount() {
        return arrayList.size();
    }
    @Override
    public boolean isEmpty() {
        return false;
    }

    public void deleteLeave(String name, String sDate, String eDate) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("USERDETAILS", MODE_PRIVATE);
        String value = sharedPreferences.getString("JSON", "");
        try {
            JSONArray arr = new JSONArray(value);
            for(int i=0; i<arr.length(); i++)
            {
                JSONObject obj = arr.getJSONObject(i);
                String nameO = obj.getString("name");
                if (nameO.equals(name)){
                    JSONArray leavesArr = obj.getJSONArray("leave");
                    for(int j=0; j<arr.length(); j++) {
                        JSONObject leaveObj = leavesArr.getJSONObject(j);
                        String startDate = leaveObj.getString("start_date");
                        String endDate = leaveObj.getString("end_date");
                        if (startDate.equals(sDate) && endDate.equals(eDate)){
                            leaveObj.put("status","DELETED");
                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            editor.putString("JSON", arr.toString()).commit();
                        }
                    }
                }
            }
        } catch (Exception e) {

        }

    }
}

