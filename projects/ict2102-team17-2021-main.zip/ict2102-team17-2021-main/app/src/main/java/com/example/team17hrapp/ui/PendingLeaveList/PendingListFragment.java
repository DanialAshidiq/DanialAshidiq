package com.example.team17hrapp.ui.PendingLeaveList;

import static android.content.Context.MODE_PRIVATE;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.team17hrapp.CustomAdapterPending;
import com.example.team17hrapp.PendingLeave;
import com.example.team17hrapp.databinding.FragmentPendinglistBinding;
import com.example.team17hrapp.ui.dashboard.DashboardViewModel;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class PendingListFragment extends Fragment {

    private DashboardViewModel dashboardViewModel;
    private FragmentPendinglistBinding binding;
    ArrayList<PendingLeave> arrayList = new ArrayList<PendingLeave>();


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        dashboardViewModel =
                new ViewModelProvider(this).get(DashboardViewModel.class);

        binding = FragmentPendinglistBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final ListView list = binding.list;
        SharedPreferences sh = getActivity().getSharedPreferences("USERDETAILS", MODE_PRIVATE);
        String uid = sh.getString("UID", "");
        arrayList = getPendingLeaves();
        CustomAdapterPending customAdapter = new CustomAdapterPending(getActivity(), arrayList);
        list.setAdapter(customAdapter);



        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    public ArrayList<PendingLeave> getPendingLeaves() {
        SharedPreferences sharedPreferences = this.getActivity().getSharedPreferences("USERDETAILS", MODE_PRIVATE);
        String value = sharedPreferences.getString("JSON", "");
        try {
            JSONArray arr = new JSONArray(value);
            for(int i=0; i<arr.length(); i++)
            {
                JSONObject obj = arr.getJSONObject(i);
                String name = obj.getString("name");
                JSONArray arrA = obj.getJSONArray("leave");
                    for (int j = 0; j < arrA.length(); j++) {
                        JSONObject objLeave = arrA.getJSONObject(j);
                        String status = objLeave.getString("status");
                        if(status.equals("Pending")){
                            String type = objLeave.getString("name");
                            String sDate = objLeave.getString("start_date");
                            String eDate = objLeave.getString("end_date");
                            String days = objLeave.getString("days");
                            String comments = objLeave.getString("comments");
                            PendingLeave a = new PendingLeave(name,type,status,sDate,eDate,days,comments);
                            arrayList.add(a);
                        }
                    }
                }

        } catch (Exception e) {

        }
        return arrayList;
    }
}