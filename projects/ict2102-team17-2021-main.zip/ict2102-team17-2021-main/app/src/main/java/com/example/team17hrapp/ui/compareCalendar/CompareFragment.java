package com.example.team17hrapp.ui.compareCalendar;

import static android.content.Context.MODE_PRIVATE;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.applandeo.materialcalendarview.EventDay;
import com.example.team17hrapp.R;
import com.example.team17hrapp.databinding.FragmentCompareBinding;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class CompareFragment extends Fragment {

    private CompareViewModel compareViewModel;
    private FragmentCompareBinding binding;
    List<EventDay> events = new ArrayList<>();
    List<EventDay> eventsUser = new ArrayList<>();
    List<EventDay> eventsA = new ArrayList<>();
    List<EventDay> eventsB = new ArrayList<>();

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        compareViewModel =
                new ViewModelProvider(this).get(CompareViewModel.class);

        binding = FragmentCompareBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        SharedPreferences sh = getActivity().getSharedPreferences("USERDETAILS", MODE_PRIVATE);
        String uid = sh.getString("UID", "");

        final com.applandeo.materialcalendarview.CalendarView view = binding.calendarViewCompare;
        final com.applandeo.materialcalendarview.CalendarView viewA = binding.calendarViewA;
        final com.applandeo.materialcalendarview.CalendarView viewB = binding.calendarViewB;



        //add button to return to prev page maybe. or just use back button

        eventsUser = getEvents(uid);
        eventsA = getEventsA();
        eventsB = getEventsB();

        view.setEvents(eventsUser);
        viewA.setEvents(eventsA);
        viewB.setEvents(eventsB);






        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    public List<EventDay> getEvents(String uid){
        SharedPreferences sharedPreferences = this.getActivity().getSharedPreferences("USERDETAILS", MODE_PRIVATE);
        String value = sharedPreferences.getString("JSON", "");
        try {
            JSONArray arr = new JSONArray(value);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                if (obj.getString("userid").equals(uid)) {
                    JSONArray arrA = obj.getJSONArray("leave");
                    for (int j = 0; j < arrA.length(); j++) {
                        JSONObject objLeave = arrA.getJSONObject(j);
                        String type = objLeave.getString("name");
                        if (type.equals("Maternity Leave")){
                            String sDate = objLeave.getString("start_date");
                            String eDate = objLeave.getString("end_date");
                            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                            Date convertedCurrentDate = null;
                            try {
                                convertedCurrentDate = sdf.parse(sDate);
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
                            Date convertedCurrentDate2 = null;
                            try {
                                convertedCurrentDate2 = sdf.parse(eDate);
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
//                        date.add(convertedCurrentDate);
                            Log.d("First Date", convertedCurrentDate.toString());
                            Log.d("2nd Date", convertedCurrentDate2.toString());

                            Integer days = getDaysDifference(convertedCurrentDate, convertedCurrentDate2);
                            Log.d("No of Days", days.toString());
                            Calendar test = toCalendar(convertedCurrentDate);
                            events.add(new EventDay(test, R.drawable.orange));


                            for (int k = 0; k < days + 1; k++) {
                                Calendar a = toCalendar(convertedCurrentDate);
                                a.add(Calendar.DAY_OF_MONTH, k);
                                Log.d("A", a.getTime().toString());
                                events.add(new EventDay(a, R.drawable.orange));
                                Log.d("events size", events.size() + "");

                            }
                        }else if(type.equals("Compassionate Leave")){
                            String sDate = objLeave.getString("start_date");
                            String eDate = objLeave.getString("end_date");
                            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                            Date convertedCurrentDate = null;
                            try {
                                convertedCurrentDate = sdf.parse(sDate);
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
                            Date convertedCurrentDate2 = null;
                            try {
                                convertedCurrentDate2 = sdf.parse(eDate);
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
//                        date.add(convertedCurrentDate);
                            Log.d("First Date", convertedCurrentDate.toString());
                            Log.d("2nd Date", convertedCurrentDate2.toString());

                            Integer days = getDaysDifference(convertedCurrentDate, convertedCurrentDate2);
                            Log.d("No of Days", days.toString());
                            Calendar test = toCalendar(convertedCurrentDate);
                            events.add(new EventDay(test, R.drawable.grey));


                            for (int k = 0; k < days + 1; k++) {
                                Calendar a = toCalendar(convertedCurrentDate);
                                a.add(Calendar.DAY_OF_MONTH, k);
                                Log.d("A", a.getTime().toString());
                                events.add(new EventDay(a, R.drawable.grey));
                                Log.d("events size", events.size() + "");

                            }


                        }else{
                            String sDate = objLeave.getString("start_date");
                            String eDate = objLeave.getString("end_date");
                            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                            Date convertedCurrentDate = null;
                            try {
                                convertedCurrentDate = sdf.parse(sDate);
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
                            Date convertedCurrentDate2 = null;
                            try {
                                convertedCurrentDate2 = sdf.parse(eDate);
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
//                        date.add(convertedCurrentDate);
                            Log.d("First Date", convertedCurrentDate.toString());
                            Log.d("2nd Date", convertedCurrentDate2.toString());

                            Integer days = getDaysDifference(convertedCurrentDate, convertedCurrentDate2);
                            Log.d("No of Days", days.toString());
                            Calendar test = toCalendar(convertedCurrentDate);
                            events.add(new EventDay(test, R.drawable.black));


                            for (int k = 0; k < days + 1; k++) {
                                Calendar a = toCalendar(convertedCurrentDate);
                                a.add(Calendar.DAY_OF_MONTH, k);
                                Log.d("A", a.getTime().toString());
                                events.add(new EventDay(a, R.drawable.black));
                                Log.d("events size", events.size() + "");

                            }
                        }
                    }
                }
            }
        } catch (Exception e) {

        }
        return events;
    }
    public static int getDaysDifference(Date fromDate,Date toDate)
    {
        if(fromDate==null||toDate==null)
            return 0;

        return (int)( (toDate.getTime() - fromDate.getTime()) / (1000 * 60 * 60 * 24));
    }
    public static Calendar toCalendar(Date date){
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        return cal;
    }
    public List<EventDay> getEventsA(){
        SharedPreferences sharedPreferences = this.getActivity().getSharedPreferences("USERDETAILS", MODE_PRIVATE);
        String value = sharedPreferences.getString("JSON", "");
        try {
            JSONArray arr = new JSONArray(value);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                if (obj.getString("userid").equals("staff1")) {
                    JSONArray arrA = obj.getJSONArray("leave");
                    for (int j = 0; j < arrA.length(); j++) {
                        JSONObject objLeave = arrA.getJSONObject(j);
                        String type = objLeave.getString("name");
                        if (type.equals("Maternity Leave")) {
                            String sDate = objLeave.getString("start_date");
                            String eDate = objLeave.getString("end_date");
                            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                            Date convertedCurrentDate = null;
                            try {
                                convertedCurrentDate = sdf.parse(sDate);
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
                            Date convertedCurrentDate2 = null;
                            try {
                                convertedCurrentDate2 = sdf.parse(eDate);
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
//                        date.add(convertedCurrentDate);
                            Log.d("First Date", convertedCurrentDate.toString());
                            Log.d("2nd Date", convertedCurrentDate2.toString());

                            Integer days = getDaysDifference(convertedCurrentDate, convertedCurrentDate2);
                            Log.d("No of Days", days.toString());
                            Calendar test = toCalendar(convertedCurrentDate);
                            eventsA.add(new EventDay(test, R.drawable.orange));


                            for (int k = 0; k < days + 1; k++) {
                                Calendar a = toCalendar(convertedCurrentDate);
                                a.add(Calendar.DAY_OF_MONTH, k);
                                Log.d("A", a.getTime().toString());
                                eventsA.add(new EventDay(a, R.drawable.orange));
                                Log.d("events size", eventsA.size() + "");

                            }
                        } else if (type.equals("Compassionate Leave")) {
                            String sDate = objLeave.getString("start_date");
                            String eDate = objLeave.getString("end_date");
                            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                            Date convertedCurrentDate = null;
                            try {
                                convertedCurrentDate = sdf.parse(sDate);
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
                            Date convertedCurrentDate2 = null;
                            try {
                                convertedCurrentDate2 = sdf.parse(eDate);
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
//                        date.add(convertedCurrentDate);
                            Log.d("First Date", convertedCurrentDate.toString());
                            Log.d("2nd Date", convertedCurrentDate2.toString());

                            Integer days = getDaysDifference(convertedCurrentDate, convertedCurrentDate2);
                            Log.d("No of Days", days.toString());
                            Calendar test = toCalendar(convertedCurrentDate);
                            eventsA.add(new EventDay(test, R.drawable.grey));


                            for (int k = 0; k < days + 1; k++) {
                                Calendar a = toCalendar(convertedCurrentDate);
                                a.add(Calendar.DAY_OF_MONTH, k);
                                Log.d("A", a.getTime().toString());
                                eventsA.add(new EventDay(a, R.drawable.grey));
                                Log.d("events size", eventsB.size() + "");

                            }


                        } else {
                            String sDate = objLeave.getString("start_date");
                            String eDate = objLeave.getString("end_date");
                            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                            Date convertedCurrentDate = null;
                            try {
                                convertedCurrentDate = sdf.parse(sDate);
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
                            Date convertedCurrentDate2 = null;
                            try {
                                convertedCurrentDate2 = sdf.parse(eDate);
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
//                        date.add(convertedCurrentDate);
                            Log.d("First Date", convertedCurrentDate.toString());
                            Log.d("2nd Date", convertedCurrentDate2.toString());

                            Integer days = getDaysDifference(convertedCurrentDate, convertedCurrentDate2);
                            Log.d("No of Days", days.toString());
                            Calendar test = toCalendar(convertedCurrentDate);
                            eventsA.add(new EventDay(test, R.drawable.black));


                            for (int k = 0; k < days + 1; k++) {
                                Calendar a = toCalendar(convertedCurrentDate);
                                a.add(Calendar.DAY_OF_MONTH, k);
                                Log.d("A", a.getTime().toString());
                                eventsA.add(new EventDay(a, R.drawable.black));
                                Log.d("events size", eventsA.size() + "");

                            }
                        }
                    }
                }
            }
        } catch (Exception e) {

        }
        return eventsA;
    }
    public List<EventDay> getEventsB(){
        SharedPreferences sharedPreferences = this.getActivity().getSharedPreferences("USERDETAILS", MODE_PRIVATE);
        String value = sharedPreferences.getString("JSON", "");
        try {
            JSONArray arr = new JSONArray(value);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                if (obj.getString("userid").equals("staff2")) {
                    JSONArray arrA = obj.getJSONArray("leave");
                    for (int j = 0; j < arrA.length(); j++) {
                        JSONObject objLeave = arrA.getJSONObject(j);
                        String type = objLeave.getString("name");
                        if (type.equals("Maternity Leave")) {
                            String sDate = objLeave.getString("start_date");
                            String eDate = objLeave.getString("end_date");
                            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                            Date convertedCurrentDate = null;
                            try {
                                convertedCurrentDate = sdf.parse(sDate);
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
                            Date convertedCurrentDate2 = null;
                            try {
                                convertedCurrentDate2 = sdf.parse(eDate);
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
//                        date.add(convertedCurrentDate);
                            Log.d("First Date", convertedCurrentDate.toString());
                            Log.d("2nd Date", convertedCurrentDate2.toString());

                            Integer days = getDaysDifference(convertedCurrentDate, convertedCurrentDate2);
                            Log.d("No of Days", days.toString());
                            Calendar test = toCalendar(convertedCurrentDate);
                            eventsB.add(new EventDay(test, R.drawable.orange));


                            for (int k = 0; k < days + 1; k++) {
                                Calendar a = toCalendar(convertedCurrentDate);
                                a.add(Calendar.DAY_OF_MONTH, k);
                                Log.d("A", a.getTime().toString());
                                eventsB.add(new EventDay(a, R.drawable.orange));
                                Log.d("events size", eventsB.size() + "");

                            }
                        } else if (type.equals("Compassionate Leave")) {
                            String sDate = objLeave.getString("start_date");
                            String eDate = objLeave.getString("end_date");
                            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                            Date convertedCurrentDate = null;
                            try {
                                convertedCurrentDate = sdf.parse(sDate);
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
                            Date convertedCurrentDate2 = null;
                            try {
                                convertedCurrentDate2 = sdf.parse(eDate);
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
//                        date.add(convertedCurrentDate);
                            Log.d("First Date", convertedCurrentDate.toString());
                            Log.d("2nd Date", convertedCurrentDate2.toString());

                            Integer days = getDaysDifference(convertedCurrentDate, convertedCurrentDate2);
                            Log.d("No of Days", days.toString());
                            Calendar test = toCalendar(convertedCurrentDate);
                            eventsB.add(new EventDay(test, R.drawable.grey));


                            for (int k = 0; k < days + 1; k++) {
                                Calendar a = toCalendar(convertedCurrentDate);
                                a.add(Calendar.DAY_OF_MONTH, k);
                                Log.d("A", a.getTime().toString());
                                eventsB.add(new EventDay(a, R.drawable.grey));
                                Log.d("events size", eventsB.size() + "");

                            }


                        } else {
                            String sDate = objLeave.getString("start_date");
                            String eDate = objLeave.getString("end_date");
                            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                            Date convertedCurrentDate = null;
                            try {
                                convertedCurrentDate = sdf.parse(sDate);
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
                            Date convertedCurrentDate2 = null;
                            try {
                                convertedCurrentDate2 = sdf.parse(eDate);
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
//                        date.add(convertedCurrentDate);
                            Log.d("First Date", convertedCurrentDate.toString());
                            Log.d("2nd Date", convertedCurrentDate2.toString());

                            Integer days = getDaysDifference(convertedCurrentDate, convertedCurrentDate2);
                            Log.d("No of Days", days.toString());
                            Calendar test = toCalendar(convertedCurrentDate);
                            eventsB.add(new EventDay(test, R.drawable.black));


                            for (int k = 0; k < days + 1; k++) {
                                Calendar a = toCalendar(convertedCurrentDate);
                                a.add(Calendar.DAY_OF_MONTH, k);
                                Log.d("A", a.getTime().toString());
                                eventsB.add(new EventDay(a, R.drawable.black));
                                Log.d("events size", eventsB.size() + "");

                            }
                        }
                    }
                }
            }
        } catch (Exception e) {

        }
        return eventsB;
    }
}