package com.example.team17hrapp;


import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupWindow;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class LoginActivity extends AppCompatActivity {
    EditText etID,etPass;
    ArrayList<Account> accList = new ArrayList<Account>();
    Boolean exist = false;
    String USERid;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);
        etID = (EditText) findViewById(R.id.editEmployeeID);
        etPass = (EditText) findViewById(R.id.editPassword);
        accList = get_json();




    }
    public void login(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        String id = etID.getText().toString();
        String pass = etPass.getText().toString();

        for(int i=0; i<accList.size(); i++) {
            Account logged = accList.get(i);
            String uid = logged.getUserid();
            String passAcc = logged.getPassword();

            if (id.equals(uid)) {
                if (pass.equals(passAcc)) {
                    USERid = uid;
                    exist = true;
                }
            }
        }
        if (exist == true){
            exist = false; //reset the variable
            Intent next = new Intent(this,MainActivity.class);
            SharedPreferences sharedPreferences = getSharedPreferences("USERDETAILS",MODE_PRIVATE);
            SharedPreferences.Editor myEdit = sharedPreferences.edit();
            myEdit.putString("UID", id);
            myEdit.commit();
            next.putExtra("UID",id);
            startActivity(next);
        }else{
            Log.d("id",id);
            LayoutInflater inflater = (LayoutInflater)
                    getSystemService(LAYOUT_INFLATER_SERVICE);
            View popupView = inflater.inflate(R.layout.popup_window, null);

            // create the popup window
            int width = LinearLayout.LayoutParams.WRAP_CONTENT;
            int height = LinearLayout.LayoutParams.WRAP_CONTENT;
//                boolean focusable = true; // lets taps outside the popup also dismiss it
            final PopupWindow popupWindow = new PopupWindow(popupView, width, height, true);

            // show the popup window
            // which view you pass in doesn't matter, it is only used for the window tolken
            popupWindow.showAtLocation(view, Gravity.CENTER, 0, 0);

            // dismiss the popup window when touched
            popupView.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    popupWindow.dismiss();
                    return true;
                }
            });
        }


        }



    public ArrayList<Account> get_json()
    {
        String json = null;
        try{
            InputStream is = this.getApplicationContext().getAssets().open("data.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer,"UTF-8");
            JSONArray jsonArray = new JSONArray(json);
            SharedPreferences sharedPreferences = getSharedPreferences("USERDETAILS", MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("JSON", jsonArray.toString()).commit();
            for(int i=0; i<jsonArray.length(); i++)
            {
                JSONObject obj = jsonArray.getJSONObject(i);
//                Log.d("test","INSIDE LOOP");
                Account a = new Account(obj.getString("userid"),obj.getString("password"));
                accList.add(a);

            }


        } catch (IOException e)
        {
            e.printStackTrace();
        } catch (JSONException e)
        {
            e.printStackTrace();
        }
        return accList;


    }

    public String getMyData() {
        return USERid;
    }

}