package com.example.team17hrapp.ui.attendance;

import static android.content.Context.MODE_PRIVATE;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.team17hrapp.AttendanceCheckOut;
import com.example.team17hrapp.databinding.FragmentAttendanceBinding;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class AttendanceFragment extends Fragment {

    private AttendanceViewModel attendanceViewModel;
    private FragmentAttendanceBinding binding;
    ArrayList<String> arrayList = new ArrayList<String>();


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        attendanceViewModel =
                new ViewModelProvider(this).get(AttendanceViewModel.class);



        binding = FragmentAttendanceBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final TextView tvName = binding.tvName;
        final TextView tvDate = binding.tvDate;
        final TextView tvTime = binding.tvTime;
        final Spinner spin = binding.spinnerLocation;
        final Button checkIn = binding.button4;

        SharedPreferences sh = this.getActivity().getSharedPreferences("USERDETAILS", MODE_PRIVATE);
        String uid = sh.getString("UID", "");

        //get JSON funct
        arrayList = getName(uid);



        String[] locations = {"Tampines Hub", "Yio Chu Kang", "Tanjong Pagar", "Woodlands", "Choa Chu Kang"};


        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item, locations);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin.setAdapter(dataAdapter);

        Calendar c =  Calendar.getInstance();
        SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
        SimpleDateFormat dft = new SimpleDateFormat("HH:mm a");
        String date = df.format(c.getTime());
        String time = dft.format(c.getTime());
        tvName.setText(arrayList.get(0).toString());
        tvDate.setText(date);
        tvTime.setText(time);

        ;

        checkIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //edit json and send to sharedpref
                String locationSelect = spin.getSelectedItem().toString();
                set_attendance(uid,locationSelect,time);
                Intent intent = new Intent(getActivity(), AttendanceCheckOut.class);
                startActivity(intent);

            }
        });




        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    public ArrayList<String> getName(String uid) {
        SharedPreferences sharedPreferences = this.getActivity().getSharedPreferences("USERDETAILS", MODE_PRIVATE);
        String value = sharedPreferences.getString("JSON", "");
        try {
            JSONArray arr = new JSONArray(value);
            for(int i=0; i<arr.length(); i++)
            {
                JSONObject obj = arr.getJSONObject(i);
                if(obj.getString("userid").equals(uid))
                {
                    String name = obj.getString("name");
                    arrayList.add(name);


                }
            }
        } catch (Exception e) {

        }
        return arrayList;
    }

    public void set_attendance(String uid,String location,String time) {
        SharedPreferences sharedPreferences = this.getActivity().getSharedPreferences("USERDETAILS", MODE_PRIVATE);
        String value = sharedPreferences.getString("JSON", "");
        try {
            JSONArray arr = new JSONArray(value);
            for(int i=0; i<arr.length(); i++)
            {
                JSONObject obj = arr.getJSONObject(i);
                if(obj.getString("userid").equals(uid))
                {
                    JSONArray arrA = obj.getJSONArray("Attendance");
                    JSONObject attObjA = arrA.getJSONObject(0);
                    attObjA.put("isAttendance",true);
                    attObjA.put("location",location);
                    attObjA.put("time",time);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("JSON", arr.toString()).commit();
                }
            }
        } catch (Exception e) {

        }


    }





}