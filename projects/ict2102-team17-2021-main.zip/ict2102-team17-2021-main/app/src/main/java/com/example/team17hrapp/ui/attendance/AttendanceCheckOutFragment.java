package com.example.team17hrapp.ui.attendance;

import static android.content.Context.MODE_PRIVATE;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.team17hrapp.AttendanceActivity;


import com.example.team17hrapp.databinding.FragmentCheckoutBinding;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;


public class AttendanceCheckOutFragment extends Fragment {
    private FragmentCheckoutBinding binding;
    ArrayList<String> LocList = new ArrayList<String>();

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentCheckoutBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final TextView tvLocation = binding.tvLocation;
        final Button checkout = binding.btnCheckOut;
        SharedPreferences sh = getActivity().getSharedPreferences("USERDETAILS", MODE_PRIVATE);
        String uid = sh.getString("UID", "");

        //get from json then set text
        LocList = getLocation(uid);
        tvLocation.setText(LocList.get(0).toString());

        checkout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder1 = new AlertDialog.Builder(getActivity());
                builder1.setMessage("Are you sure you want to check out?");
                builder1.setCancelable(false);

                builder1.setPositiveButton(
                        "Cancel",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
                builder1.setNeutralButton(
                        "Check Out",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                set_attendance(uid,false);
//                                atList = get_Attendance(uid);
//                                Log.d("BEFORE CHECKOUT ATLIST ", atList.get(0).toString());
                                Intent intent = new Intent(getActivity(), AttendanceActivity.class);
                                startActivity(intent);
                            }
                        });

                AlertDialog alert11 = builder1.create();
                alert11.show();



                
            }
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    public void set_attendance(String uid,boolean a) {
        SharedPreferences sharedPreferences = this.getActivity().getSharedPreferences("USERDETAILS", MODE_PRIVATE);
        String value = sharedPreferences.getString("JSON", "");
        try {
            JSONArray arr = new JSONArray(value);
            for(int i=0; i<arr.length(); i++)
            {
                JSONObject obj = arr.getJSONObject(i);
                if(obj.getString("userid").equals(uid))
                {
                    JSONArray arrA = obj.getJSONArray("Attendance");
                    JSONObject attObjA = arrA.getJSONObject(0);
                    attObjA.put("isAttendance",a);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("JSON", arr.toString()).commit();
                }
            }
        } catch (Exception e) {

        }


    }

    public ArrayList<String> getLocation(String uid) {
        SharedPreferences sharedPreferences = this.getActivity().getSharedPreferences("USERDETAILS", MODE_PRIVATE);
        String value = sharedPreferences.getString("JSON", "");
        try {
            JSONArray arr = new JSONArray(value);
            for(int i=0; i<arr.length(); i++)
            {
                JSONObject obj = arr.getJSONObject(i);
                if(obj.getString("userid").equals(uid))
                {
                    JSONArray arrA = obj.getJSONArray("Attendance");
                    JSONObject objA = arrA.getJSONObject(0);
                    String loc = objA.getString("location");
                    LocList.add(loc);


                }
            }
        } catch (Exception e) {

        }
        return LocList;
    }



}

