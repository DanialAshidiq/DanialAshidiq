package com.example.team17hrapp;

public class Attendance {
    String location;
    Boolean isAttendance;
    String checkInTime;



    public Attendance(String location, Boolean isAttendance, String checkInTime) {
        this.location = location;
        this.isAttendance = isAttendance;
        this.checkInTime = checkInTime;

    }

    public String getLocation() {
        return location;
    }

    public Boolean getAttendance() {
        return isAttendance;
    }

    public String getCheckInTime() {
        return checkInTime;
    }
}