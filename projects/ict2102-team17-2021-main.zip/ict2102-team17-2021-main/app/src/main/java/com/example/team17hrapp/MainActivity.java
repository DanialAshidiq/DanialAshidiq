package com.example.team17hrapp;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.team17hrapp.databinding.ActivityMainBinding;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    public String USERID;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            USERID = extras.getString("UID");
            //The key argument here must match that used in the other activity
        }


        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        BottomNavigationView navView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
//        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
//                R.id.navigation_calendar, R.id.navigation_applyleave,R.id.navigation_home,R.id.navigation_scanqr, R.id.navigation_notifications)
//                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_activity_main);
//        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(binding.navView, navController);

    }

    public String getMyData() {
        return USERID;
    }

    public void onBackPressed() {
        //disable back button
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //Initialize intent result
        IntentResult intentResult = IntentIntegrator.parseActivityResult(
                requestCode,resultCode,data
        );
      //Check condition
        if (intentResult.getContents() != null){
            Log.d("QR","SCAN SUCCESS");
            if (intentResult.getContents().equals("Tampines Hub")){
                Log.d("QR","SCAN TAMPINES");
                SharedPreferences sh = this.getSharedPreferences("USERDETAILS", MODE_PRIVATE);
                String uid = sh.getString("UID", "");
                Calendar c =  Calendar.getInstance();
                SimpleDateFormat dft = new SimpleDateFormat("HH:mm a");
                String time = dft.format(c.getTime());
                set_attendance(uid,"Tampines Hub",time);
                NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_activity_main);
                navController.navigate(R.id.action_navigation_scanqr_to_navigation_home);
                Uri data2 = getIntent().getData();
                Log.d(getClass().getName(), "onCreate data=" + data2);
                getIntent().setData(null);

            }else if (intentResult.getContents().equals("Choa Chu Kang")){
                Log.d("QR","SCAN CCK");
                SharedPreferences sh = this.getSharedPreferences("USERDETAILS", MODE_PRIVATE);
                String uid = sh.getString("UID", "");
                Calendar c =  Calendar.getInstance();
                SimpleDateFormat dft = new SimpleDateFormat("HH:mm a");
                String time = dft.format(c.getTime());
                set_attendance(uid,"Choa Chu Kang",time);
                NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_activity_main);
                navController.navigate(R.id.action_navigation_scanqr_to_navigation_home);
                Uri data2 = getIntent().getData();
                Log.d(getClass().getName(), "onCreate data=" + data2);
                getIntent().setData(null);

            }
        }else {
            //When result content is null
            //Display toast
            Toast.makeText(getApplicationContext()
                    , "OOPS... You did not scan anything", Toast.LENGTH_SHORT)
                    .show();
        }

    }

    public void set_attendance(String uid,String location,String time) {
        SharedPreferences sharedPreferences = this.getSharedPreferences("USERDETAILS", MODE_PRIVATE);
        String value = sharedPreferences.getString("JSON", "");
        try {
            JSONArray arr = new JSONArray(value);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                if (obj.getString("userid").equals(uid)) {
                    JSONArray arrA = obj.getJSONArray("Attendance");
                    JSONObject attObjA = arrA.getJSONObject(0);
                    attObjA.put("isAttendance", true);
                    attObjA.put("location", location);
                    attObjA.put("time", time);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("JSON", arr.toString()).commit();
                }
            }
        } catch (Exception e) {

        }
    }

}