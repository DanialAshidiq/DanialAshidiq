package com.example.team17hrapp;

class Account {
    String userid;
    String password;



    public Account(String userid, String password) {
        this.userid = userid;
        this.password = password;

    }

    public String getUserid() {
        return userid;
    }

    public String getPassword() {
        return password;
    }
}