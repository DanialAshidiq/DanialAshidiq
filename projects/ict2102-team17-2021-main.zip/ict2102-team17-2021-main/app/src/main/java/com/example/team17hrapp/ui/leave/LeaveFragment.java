package com.example.team17hrapp.ui.leave;

import static android.content.Context.LAYOUT_INFLATER_SERVICE;
import static android.content.Context.MODE_PRIVATE;

import static com.example.team17hrapp.App.CHANNEL_1_ID;

import android.app.AlertDialog;
import android.app.Notification;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.applandeo.materialcalendarview.EventDay;
import com.applandeo.materialcalendarview.listeners.OnDayClickListener;
import com.example.team17hrapp.AttendanceActivity;
import com.example.team17hrapp.R;
import com.example.team17hrapp.databinding.FragmentLeaveBinding;
import com.example.team17hrapp.ui.leave.LeaveViewModel;


import org.json.JSONArray;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class LeaveFragment extends Fragment {
    private LeaveViewModel leaveViewModel;
    private FragmentLeaveBinding binding;
    private NotificationManagerCompat notificationManager;
    List<EventDay> events = new ArrayList<>();
    List<Date> date = new ArrayList<>();

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        leaveViewModel =
                new ViewModelProvider(this).get(LeaveViewModel.class);

        binding = FragmentLeaveBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final com.applandeo.materialcalendarview.CalendarView view = binding.calendarView;
        final EditText etStart = binding.etStartDate;
        final EditText etEnd = binding.etEndDate;
        final EditText etComments = binding.etComment;
        final TextView tvApplyMore = binding.tvApplyMore;
        final LinearLayout lvLeave1 = binding.leave1LV;
        final Button update = binding.btnUpdate;
        final Button delete = binding.btnDelete;
        final Spinner spin = binding.spinner;
        final String[] types = new String[10];
        final String[] sDate = new String[10];
        final String[] eDate = new String[10];
        final String[] comments = new String[10];
        final Integer[] Days = new Integer[10];
        final ImageButton ibInfo = binding.ibInfo;

        ibInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LayoutInflater inflater = (LayoutInflater)
                        getActivity().getSystemService(LAYOUT_INFLATER_SERVICE);
                View popupView = inflater.inflate(R.layout.popup_leaveinfo, null);

                // create the popup window
                int width = LinearLayout.LayoutParams.WRAP_CONTENT;
                int height = LinearLayout.LayoutParams.WRAP_CONTENT;
//                boolean focusable = true; // lets taps outside the popup also dismiss it
                final PopupWindow popupWindow = new PopupWindow(popupView, width, height, true);

                // show the popup window
                // which view you pass in doesn't matter, it is only used for the window tolken
                popupWindow.showAtLocation(view, Gravity.CENTER, 0, 0);

                // dismiss the popup window when touched
                popupView.setOnTouchListener(new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View v, MotionEvent event) {
                        popupWindow.dismiss();
                        return true;
                    }
                });
            }
        });



        notificationManager = NotificationManagerCompat.from(getActivity());


        final Button submit = binding.buttonSubmit;
        etStart.setTextColor(Color.GRAY);
        etEnd.setTextColor(Color.GRAY);
        String[] leaves = {"Annual Leave", "Childcare Leave", "Hospitalization Leave", "PM Leave", "Time Off"};


        SharedPreferences sh = getActivity().getSharedPreferences("USERDETAILS", MODE_PRIVATE);
        String uid = sh.getString("UID", "");


        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item, leaves);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin.setAdapter(dataAdapter);


        spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                types[0] = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        List<String> dates = new ArrayList<String>();
        List<String> datesToAdd = new ArrayList<String>();
        //disable weekends for leave application.
        Calendar sunday;
        Calendar saturday;
        List<Calendar> weekends = new ArrayList<>();
        int weeks = 10;
        for (int i = 0; i < (weeks * 7); i = i + 7) {
            for (int j = 0; j > (weeks * 7); j = j - 7) ;
            sunday = Calendar.getInstance();
            sunday.add(Calendar.DAY_OF_YEAR, (Calendar.SUNDAY - sunday.get(Calendar.DAY_OF_WEEK) + 7 + i));
            saturday = Calendar.getInstance();
            saturday.add(Calendar.DAY_OF_YEAR, (Calendar.SATURDAY - saturday.get(Calendar.DAY_OF_WEEK) + i));
            weekends.add(saturday);
            weekends.add(sunday);
        }
        view.setDisabledDays(weekends);



        events = getEvents(uid);



        view.setEvents(events);



        view.setOnDayClickListener(new OnDayClickListener() {
            @Override
            public void onDayClick(EventDay eventDay) {
                if (dates.size() == 0) {
                    etStart.setTextColor(Color.BLACK);
                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                    String firstDate = sdf.format(eventDay.getCalendar().getTime());
                    SimpleDateFormat dd = new SimpleDateFormat("dd");
                    String sDay = dd.format(eventDay.getCalendar().getTime());
                    Integer days = Integer.parseInt(sDay);
                    Days[0] = days;
                    sDate[0] = firstDate;
                    etStart.setText(firstDate);
                    dates.add(firstDate);
                    datesToAdd.add(firstDate);

                } else {
                    etEnd.setTextColor(Color.BLACK);
                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                    String endDate = sdf.format(eventDay.getCalendar().getTime());
                    SimpleDateFormat dd = new SimpleDateFormat("dd");
                    String sDay = dd.format(eventDay.getCalendar().getTime());
                    Integer days = Integer.parseInt(sDay);
                    Days[0] = days - Days[0];
                    eDate[0] = endDate;
                    etEnd.setText(endDate);
                    dates.add(endDate);
                    datesToAdd.add(endDate);
                    dates.remove(0); //need to reset
                    dates.remove(0); //need to reset
                }


            }
        });


        tvApplyMore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (sDate[0] == null && eDate[0] == null) {
                    //show popup/dialog to enter dates.
                    LayoutInflater inflater = (LayoutInflater) getActivity().getSystemService(LAYOUT_INFLATER_SERVICE);
                    View popupView = inflater.inflate(R.layout.popup_window_leave, null);

                    // create the popup window
                    int width = LinearLayout.LayoutParams.WRAP_CONTENT;
                    int height = LinearLayout.LayoutParams.WRAP_CONTENT;
                    final PopupWindow popupWindow = new PopupWindow(popupView, width, height, true);

                    popupWindow.showAtLocation(view, Gravity.CENTER, 0, 0);

                    popupView.setOnTouchListener(new View.OnTouchListener() {
                        @Override
                        public boolean onTouch(View v, MotionEvent event) {
                            popupWindow.dismiss();
                            return true;
                        }
                    });
                } else {
                    lvLeave1.setVisibility(View.GONE);
                    FrameLayout container = binding.flContainer;
                    View inflatedLayout = getLayoutInflater().inflate(R.layout.applymore_initial, null, false);
                    container.addView(inflatedLayout);

                    TextView type = (TextView) inflatedLayout.findViewById(R.id.tvInitialType);
                    TextView start = (TextView) inflatedLayout.findViewById(R.id.tvInitialStart);
                    TextView end = (TextView) inflatedLayout.findViewById(R.id.tvInitialEnd);
                    TextView comment = (TextView) inflatedLayout.findViewById(R.id.tvInitialComment);
                    type.setTextColor(Color.BLACK);
                    start.setTextColor(Color.BLACK);
                    end.setTextColor(Color.BLACK);
                    comment.setTextColor(Color.BLACK);
                    comments[0] = etComments.getText().toString();
                    types[1] = types[0];
                    sDate[1] = sDate[0];
                    eDate[1] = eDate[0];
                    comments[1] = comments[0];
                    type.setText("Leave type: " + types[0].toString());
                    start.setText("Start Date: " + sDate[0].toString());
                    end.setText("End Date: " + eDate[0].toString());
                    comment.setText("Comments: " + comments[0].toString());
                    etStart.setText("");
                    etEnd.setText("");
                    etComments.setText("");
                    tvApplyMore.setVisibility(View.GONE);
                    spin.setSelection(0);
                    lvLeave1.setVisibility(View.VISIBLE);


                    ImageButton editLeaveButton = (ImageButton) inflatedLayout.findViewById(R.id.editLeaveButton);
                    editLeaveButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
//                        Intent intent = new Intent(getActivity(), LoginActivity.class);
//                        startActivity(intent);
                            container.setVisibility(View.GONE);
                            lvLeave1.setVisibility(View.VISIBLE);
                            //select the spinner item from prev?
                            etStart.setText(sDate[0].toString());
                            etEnd.setText(eDate[0].toString());
                            tvApplyMore.setVisibility(View.GONE);
                            //add 2 buttons Update/Delete and hide submit(?)
                            submit.setVisibility(View.GONE);
                            LinearLayout extraButtons = binding.extraButtons;
                            extraButtons.setVisibility(View.VISIBLE);
                            //update container to visible set text to strings update, hide lvleave1
                        }
                    });
                }


//                parentLayout.addView(leaveLayout);
            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //confirmation dialog ARE you sure want to delete?
                etStart.setTextColor(Color.GRAY);
                etEnd.setTextColor(Color.GRAY);
                etStart.setText("Select date in Calendar");
                etEnd.setText("Select date in Calendar");
                LinearLayout extraButtons = binding.extraButtons;
                extraButtons.setVisibility(View.GONE);
                submit.setVisibility(View.VISIBLE);

            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //update container to visible set text to strings update, hide lvleave1
                // change to [1]?
                types[0] = spin.getSelectedItem().toString();
                String updatedSDate = etStart.getText().toString();
                sDate[0] = updatedSDate;
                String updatedEDate = etEnd.getText().toString();
                eDate[0] = updatedEDate;
                String updatedComment = etComments.getText().toString();
                comments[0] = updatedComment;
                lvLeave1.setVisibility(View.GONE);
                FrameLayout container = binding.flContainer;
                View inflatedLayout2 = getLayoutInflater().inflate(R.layout.applymore_initial, null, false);
                container.addView(inflatedLayout2);
                container.setVisibility(View.VISIBLE);


                TextView type = (TextView) inflatedLayout2.findViewById(R.id.tvInitialType);
                TextView start = (TextView) inflatedLayout2.findViewById(R.id.tvInitialStart);
                TextView end = (TextView) inflatedLayout2.findViewById(R.id.tvInitialEnd);
                TextView comment = (TextView) inflatedLayout2.findViewById(R.id.tvInitialComment);
                type.setTextColor(Color.BLACK);
                start.setTextColor(Color.BLACK);
                end.setTextColor(Color.BLACK);
                comment.setTextColor(Color.BLACK);
                type.setText("Leave type: " + types[0].toString());
                start.setText("Start Date: " + sDate[0].toString());
                end.setText("End Date: " + eDate[0].toString());
                comment.setText("Comments: " + comments[0].toString());
                update.setVisibility(View.GONE);
                delete.setVisibility(View.GONE);
                etStart.setText("");
                etEnd.setText("");
                etComments.setText("");
                spin.setSelection(0);
                submit.setVisibility(View.VISIBLE);
                lvLeave1.setVisibility(View.VISIBLE);


            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String type = types[0];
                String startDate = sDate[0];
                String endDate = eDate[0];
                Integer days = Days[0];
                String comm = etComments.getText().toString();
                //check if empty dates
                if (startDate == null || endDate == null) {
                    LayoutInflater inflater = (LayoutInflater) getActivity().getSystemService(LAYOUT_INFLATER_SERVICE);
                    View popupView = inflater.inflate(R.layout.popup_window_leave, null);

                    // create the popup window
                    int width = LinearLayout.LayoutParams.WRAP_CONTENT;
                    int height = LinearLayout.LayoutParams.WRAP_CONTENT;
//                boolean focusable = true; // lets taps outside the popup also dismiss it
                    final PopupWindow popupWindow = new PopupWindow(popupView, width, height, true);

                    // show the popup window
                    // which view you pass in doesn't matter, it is only used for the window tolken
                    popupWindow.showAtLocation(view, Gravity.CENTER, 0, 0);

                    // dismiss the popup window when touched
                    popupView.setOnTouchListener(new View.OnTouchListener() {
                        @Override
                        public boolean onTouch(View v, MotionEvent event) {
                            popupWindow.dismiss();
                            return true;
                        }
                    });
                } else {
                    if (types[1] == null) { //only one leave
                        addLeave(uid, type, startDate, endDate, days, comm);
//                        Intent intent = new Intent(getActivity(), LeavesActivity2.class);
//                        startActivity(intent);
                        new Handler().postDelayed(new Runnable() { //delay to mimic leave approval

                            @Override
                            public void run() {
                                //Add your code to display notification here
                                Notification notification = new NotificationCompat.Builder(getActivity(), CHANNEL_1_ID)
                                        .setSmallIcon(R.drawable.bell)
                                        .setContentTitle("Leave Approved")
                                        .setContentText("Leave has been approved.")
                                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                                        .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                        .build();

                                notificationManager.notify(1, notification);
                            }
                        }, 5000);
                        Notification notification2 = new NotificationCompat.Builder(getActivity(), CHANNEL_1_ID)
                                .setSmallIcon(R.drawable.bell)
                                .setContentTitle("Leave Application")
                                .setContentText("Leave has been applied.")
                                .setPriority(NotificationCompat.PRIORITY_HIGH)
                                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                .build();

                        notificationManager.notify(1, notification2);
                        Navigation.findNavController(v).navigate(R.id.action_navigation_applyleave_to_navigation_leaveList);
                        AlertDialog.Builder builder1 = new AlertDialog.Builder(getActivity());
                        builder1.setTitle("Leave Applied");
                        builder1.setMessage(type+"\n\nFrom: " +startDate +"\nUntil: "+endDate);
                        builder1.setCancelable(false);
                        builder1.setPositiveButton(
                                "Dismiss",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        dialog.cancel();
                                    }
                                });

                        AlertDialog alert11 = builder1.create();
                        alert11.show();
                    } else {
                        String type1 = types[1];
                        String startDate1 = sDate[1];
                        String endDate1 = eDate[1];
                        Integer days1 = Days[0];
                        String comments1 = comments[1];
                        addLeave(uid, type1, startDate1, endDate1, days1, comments1);
                        String type2 = spin.getSelectedItem().toString();
                        String startDate2 = etStart.getText().toString();
                        String endDate2 = etEnd.getText().toString();
                        Integer days2 = Days[0];
                        String comments2 = etComments.getText().toString();
                        addLeave(uid, type2, startDate2, endDate2, days2, comments2);
//                        Intent intent = new Intent(getActivity(), LeavesActivity2.class);
//                        startActivity(intent);
                        new Handler().postDelayed(new Runnable() { //delay to mimic leave approval

                            @Override
                            public void run() {
                                //Add your code to display notification here
                                Notification notification = new NotificationCompat.Builder(getActivity(), CHANNEL_1_ID)
                                        .setSmallIcon(R.drawable.bell)
                                        .setContentTitle("Leave Approved")
                                        .setContentText("Leave has been approved.")
                                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                                        .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                        .build();

                                notificationManager.notify(1, notification);
                            }
                        }, 5000);
                        Notification notification2 = new NotificationCompat.Builder(getActivity(), CHANNEL_1_ID)
                                .setSmallIcon(R.drawable.bell)
                                .setContentTitle("Leave Application")
                                .setContentText("Leave has been applied.")
                                .setPriority(NotificationCompat.PRIORITY_HIGH)
                                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                                .build();

                        notificationManager.notify(1, notification2);
                        AlertDialog.Builder builder1 = new AlertDialog.Builder(getActivity());
                        builder1.setTitle("Leaves Applied");
                        builder1.setMessage(type+"\n\nFrom: " +startDate +"\nUntil: "+endDate+"\n\n"+type2+"\n\nFrom: " +startDate2 +"\nUntil: "+endDate2);
                        builder1.setCancelable(false);
                        builder1.setPositiveButton(
                                "Dismiss",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        dialog.cancel();
                                    }
                                });

                        AlertDialog alert11 = builder1.create();
                        alert11.show();
                        Navigation.findNavController(v).navigate(R.id.action_navigation_applyleave_to_navigation_leaveList);


                    }

                }


            }
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    public void addLeave(String uid, String type, String startDate, String endDate, Integer days, String comments) {
        SharedPreferences sharedPreferences = this.getActivity().getSharedPreferences("USERDETAILS", MODE_PRIVATE);
        String value = sharedPreferences.getString("JSON", "");
        try {
            JSONArray arr = new JSONArray(value);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                if (obj.getString("userid").equals(uid)) {
                    JSONArray arrA = obj.getJSONArray("leave");
                    JSONObject leave1 = new JSONObject();
                    String id = String.valueOf(arrA.length());
                    leave1.put("id", id);
                    leave1.put("name", type);
                    leave1.put("start_date", startDate);
                    leave1.put("end_date", endDate);
                    leave1.put("days", days);
                    leave1.put("comments", comments);
                    leave1.put("status", "Pending");
                    arrA.put(leave1);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("JSON", arr.toString()).commit();
                }
            }
        } catch (Exception e) {

        }


    }


    public static Calendar toCalendar(Date date){
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        return cal;
    }

    public List<EventDay> getEvents(String uid){
        SharedPreferences sharedPreferences = this.getActivity().getSharedPreferences("USERDETAILS", MODE_PRIVATE);
        String value = sharedPreferences.getString("JSON", "");
        try {
            JSONArray arr = new JSONArray(value);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                if (obj.getString("userid").equals(uid)) {
                    JSONArray arrA = obj.getJSONArray("leave");
                    for (int j = 0; j < arrA.length(); j++) {
                        JSONObject objLeave = arrA.getJSONObject(j);
                        String type = objLeave.getString("name");
                        if (type.equals("Maternity Leave")){
                            String sDate = objLeave.getString("start_date");
                            String eDate = objLeave.getString("end_date");
                            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                            Date convertedCurrentDate = null;
                            try {
                                convertedCurrentDate = sdf.parse(sDate);
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
                            Date convertedCurrentDate2 = null;
                            try {
                                convertedCurrentDate2 = sdf.parse(eDate);
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
//                        date.add(convertedCurrentDate);
                            Log.d("First Date", convertedCurrentDate.toString());
                            Log.d("2nd Date", convertedCurrentDate2.toString());

                            Integer days = getDaysDifference(convertedCurrentDate, convertedCurrentDate2);
                            Log.d("No of Days", days.toString());
                            Calendar test = toCalendar(convertedCurrentDate);
                            events.add(new EventDay(test, R.drawable.orange));


                            for (int k = 0; k < days + 1; k++) {
                                Calendar a = toCalendar(convertedCurrentDate);
                                a.add(Calendar.DAY_OF_MONTH, k);
                                Log.d("A", a.getTime().toString());
                                events.add(new EventDay(a, R.drawable.orange));
                                Log.d("events size", events.size() + "");

                            }
                        }else if(type.equals("Compassionate Leave")){
                            String sDate = objLeave.getString("start_date");
                            String eDate = objLeave.getString("end_date");
                            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                            Date convertedCurrentDate = null;
                            try {
                                convertedCurrentDate = sdf.parse(sDate);
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
                            Date convertedCurrentDate2 = null;
                            try {
                                convertedCurrentDate2 = sdf.parse(eDate);
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
//                        date.add(convertedCurrentDate);
                            Log.d("First Date", convertedCurrentDate.toString());
                            Log.d("2nd Date", convertedCurrentDate2.toString());

                            Integer days = getDaysDifference(convertedCurrentDate, convertedCurrentDate2);
                            Log.d("No of Days", days.toString());
                            Calendar test = toCalendar(convertedCurrentDate);
                            events.add(new EventDay(test, R.drawable.grey));


                            for (int k = 0; k < days + 1; k++) {
                                Calendar a = toCalendar(convertedCurrentDate);
                                a.add(Calendar.DAY_OF_MONTH, k);
                                Log.d("A", a.getTime().toString());
                                events.add(new EventDay(a, R.drawable.grey));
                                Log.d("events size", events.size() + "");

                            }


                        }else{
                            String sDate = objLeave.getString("start_date");
                            String eDate = objLeave.getString("end_date");
                            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                            Date convertedCurrentDate = null;
                            try {
                                convertedCurrentDate = sdf.parse(sDate);
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
                            Date convertedCurrentDate2 = null;
                            try {
                                convertedCurrentDate2 = sdf.parse(eDate);
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
//                        date.add(convertedCurrentDate);
                            Log.d("First Date", convertedCurrentDate.toString());
                            Log.d("2nd Date", convertedCurrentDate2.toString());

                            Integer days = getDaysDifference(convertedCurrentDate, convertedCurrentDate2);
                            Log.d("No of Days", days.toString());
                            Calendar test = toCalendar(convertedCurrentDate);
                            events.add(new EventDay(test, R.drawable.black));


                            for (int k = 0; k < days + 1; k++) {
                                Calendar a = toCalendar(convertedCurrentDate);
                                a.add(Calendar.DAY_OF_MONTH, k);
                                Log.d("A", a.getTime().toString());
                                events.add(new EventDay(a, R.drawable.black));
                                Log.d("events size", events.size() + "");

                            }
                        }
                    }
                }
            }
        } catch (Exception e) {

        }
        return events;
    }

    public static int getDaysDifference(Date fromDate,Date toDate)
    {
        if(fromDate==null||toDate==null)
            return 0;

        return (int)( (toDate.getTime() - fromDate.getTime()) / (1000 * 60 * 60 * 24));
    }


}


