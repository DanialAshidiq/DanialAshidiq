package com.example.team17hrapp;

public class Leave {
    String name;
    String type;
    String status;
    String startDate;
    String endDate;
    String days;


    public Leave(String name, String type, String status, String startDate, String endDate, String days) {
        this.name = name;
        this.type = type;
        this.status = status;
        this.startDate = startDate;
        this.endDate = endDate;
        this.days = days;
    }

    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }

    public String getStatus() {
        return status;
    }

    public String getStartDate() {
        return startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public String getDays() {
        return days;
    }
}