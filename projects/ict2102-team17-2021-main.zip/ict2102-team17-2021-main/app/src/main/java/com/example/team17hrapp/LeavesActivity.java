package com.example.team17hrapp;

import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class LeavesActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.leaves_activity);
//        final ListView list = findViewById(R.id.list);
//        ArrayList<Leave> arrayList = new ArrayList<Leave>();
//        arrayList.add(new Leave("Annual Leave","Pending","04/11/21","12/11/21","7days"));
//        arrayList.add(new Leave("Childcare Leave","Pending","02/11/21","12/11/21","10days"));
//        arrayList.add(new Leave("Maternity Leave","Pending","01/11/21","12/11/21","11days"));
//        arrayList.add(new Leave("Annual Leave","Pending","06/11/21","12/11/21","5days"));
//        arrayList.add(new Leave("Childcare Leave","Pending","11/11/21","12/11/21","1days"));
//
//        CustomAdapter customAdapter = new CustomAdapter(this, arrayList);
//        list.setAdapter(customAdapter);

    }
}