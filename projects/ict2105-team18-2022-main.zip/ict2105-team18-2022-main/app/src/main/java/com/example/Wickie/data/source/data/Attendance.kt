package com.example.Wickie.data.source.data

import java.io.Serializable

class Attendance(var date : String, var startTime : String, var endTime : String) : Serializable {}