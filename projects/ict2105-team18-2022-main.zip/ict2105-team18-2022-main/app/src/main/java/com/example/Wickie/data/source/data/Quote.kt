package com.example.Wickie.data.source.data
import java.io.Serializable

class Quote : Serializable {
    //List of quotes for each week
    var mon_quote : String? = null
}