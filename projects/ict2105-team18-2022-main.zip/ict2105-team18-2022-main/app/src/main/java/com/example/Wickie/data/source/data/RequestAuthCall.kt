package com.example.Wickie.data.source.data

/*
* Simple class to define operations of the user class when retrieving data from firebase
*
* */
class RequestAuthCall {
    var status = 0
    var message : String = "No Message"
    var userDetail: User = User()
}