package com.example.Wickie.data.source.data
import java.io.Serializable

class User() : Serializable {
    // user_id : Int, user_name : String, user_email : String, user_pw: String, user_dob : String,
    // user_address: String, user_department: String, user_position: String, user_mobile:String
    var user_id : Int? = null


    var user_name : String? = null

    var user_email : String? = null

    var user_pw : String? = null

    var user_dob : String? = null

    var user_address: String? = null

    var user_department: String? = null

    var user_position: String? = null

    var user_mobile: String? = null

}