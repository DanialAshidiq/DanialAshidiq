package com.example.Wickie.data.source.data

class RequestAttendanceCall {
    var status = 0
    var message : String = ""
}