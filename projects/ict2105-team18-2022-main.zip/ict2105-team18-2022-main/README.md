# ict2105-team18-2022
* User Login: UserID: Asif Password: 123

* GPS only works at NYP SIT Co-ordinates: (1.4443° N, 103.7838° E)

* For chatbot, access the following site “https://chat-bot-heroku-danial.herokuapp.com/index”

Demo Video link: https://youtu.be/tjpcXyOe3Ao
