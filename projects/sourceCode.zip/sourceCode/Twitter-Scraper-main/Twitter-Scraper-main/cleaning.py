import os
import sys
import re
import pickle
import logging
import csv
import time
from collections import defaultdict
from pymongo import MongoClient

logging.getLogger().setLevel(logging.INFO)


def clean_str(s):
    s = re.sub(r"https?:\/\/\S*", "", s)  # url
    s = re.sub(r"@[\w.]+", "", s)  # user tagged
    s = re.sub(r"#[\w]+", "", s)  # hashtag
    s = re.sub(r"\$[\d\.]+", "", s)  # money
    s = re.sub(r"[^A-Za-z0-9:(),!?\'\`]", " ", s)  # unknown characters
    s = re.sub(r"\'s", "", s)
    s = re.sub(r"\'ve", "", s)
    s = re.sub(r"n\'t", "", s)
    s = re.sub(r"\'re", "", s)
    s = re.sub(r"\'d", "", s)
    s = re.sub(r"\'ll", "", s)
    s = re.sub(r"\W", " ", s)  # punctuation
    s = re.sub(r"\d", " ", s)  # number
    s = re.sub(r"\s{2,}", " ", s)  # while space
    s = re.sub(r'[^\x00-\x7F]+', "", s)  # non-ASCII
    return s.strip().lower()


# get the usertag from text
def get_usertag(s):
    m = re.findall('(?<=\@)[\w.]+', s)
    return m


# get the hashtag from text
def get_hashtag(s):
    m = re.findall('(?<=\#)[\w]+', s)
    return m


def clean_text(source, name, text):
    cleantext = []
    hashtag = []
    usertag = []
    # get the hashtag from the text
    for i in text:
        for y in get_hashtag(i):
            if y != "":
                if y not in hashtag:
                    hashtag.append(y)
        for x in get_usertag(i):
            if x != "":
                if x not in usertag:
                    usertag.append(x)
    # get the clean text
    for i in text:
        cleantext.append(clean_stopwords(clean_str(i)))


# cleanning the stopwords
def clean_stopwords(data):
    # read from the stopwords list
    stopwords_dir = "./pre_processing/stopwords.txt"
    loadStopWords = open(stopwords_dir, "r")
    stopwordArray = []
    line = (loadStopWords.read())
    tokenize = line.split("\n")
    size = len(tokenize)
    total = 1
    for t in tokenize:
        if (total < size):
            t = re.sub(r"\r", "", t)
            stopwordArray.append(t)
            total = total + 1
    word = data.split(" ")
    resultArray = []
    for i in word:
        if i not in stopwordArray:
            resultArray.append(i)
    result = " ".join(resultArray)
    return result


def cleaning():
    time.sleep(60)
    while True:
        time.sleep(60)
        post = database.find({"clean_status": False})
        for p in post:
            source = p["source"]
            name = p["user"]
            text = p["text"]
            clean_text(source, name, text)


cleaning()
