

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Hashtable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class TweetSentimentMapper extends Mapper<LongWritable, Text, Text, IntWritable>{
    Hashtable<String, String> word = new Hashtable<>();

    @Override
    protected void setup(Mapper<LongWritable, Text, Text, IntWritable>.Context context)
        throws IOException, InterruptedException {
        BufferedReader br = new BufferedReader(new FileReader("negative.csv"));
        String line = null;
        while(true) {
            line = br.readLine();
            if(line != null) {
                String parts[] = line.split(",");
                word.put(parts[1], parts[0]);
            } else {
                break;
            }
        }
        br.close();
    }
    @Override
    protected void map(LongWritable key, Text value, 
            Mapper<LongWritable, Text, Text, IntWritable>.Context context)
        throws IOException, InterruptedException {
        String[] parts = value.toString().split("\t");
        String word1 = parts[0];
        int count = Integer.parseInt(parts[1]);
        Enumeration enu = word.keys();
        if(word1 != null && count != 0) {
            while (enu.hasMoreElements()) {
                if(enu.nextElement().equals(word1)){
                	context.write(new Text(word1), new IntWritable(count));
                }
            }
//        	for (int i = 0; i < word.size(); i++) {
//        		if(word1.equals(enu){
//        			context.write(new Text(word1), new IntWritable(1));
//        		}
//        	}   
        }
    }

}