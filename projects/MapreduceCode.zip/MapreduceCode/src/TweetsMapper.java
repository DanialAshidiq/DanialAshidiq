import java.io.IOException;


import java.io.*;
import java.util.*;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class TweetsMapper extends Mapper<LongWritable, Text, Text, IntWritable> {
 Text tweet = new Text();
 IntWritable one = new IntWritable(1);

 @Override
 protected void map(LongWritable key, Text value, Mapper<LongWritable, Text, Text, IntWritable>.Context context)
   throws IOException, InterruptedException {
  String[] parts = value.toString().split(",");
  String tweetStr;
  if (parts[0] != null) {
   tweetStr = parts[0].trim();
   String[] tweets = tweetStr.split(" ");
   for (int i = 0; i < tweets.length; i++) {
    String first = tweets[i];
    if (tweetStr != null && !tweetStr.isEmpty()) {
     tweet.set(first);
     context.write(tweet, one);
    }
   }
   
  }
 }
}