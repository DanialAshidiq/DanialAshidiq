

import java.net.URI;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.chain.ChainMapper;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
public class TweetSentimentAnalysis {
    public static void main(String[] args) throws Exception {

        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "TweetSentimentAnalysis");
        job.setJarByClass(TweetSentimentAnalysis.class);

//        Path inPath = new Path(args[1]);
//        Path outPath = new Path(args[2]);
        
        Path inPath = new Path("hdfs://localhost:9000/user/phamvanvung/project/output/1649425838656/part-r-00000"); //input
        Path outPath = new Path("hdfs://localhost:9000/user/phamvanvung/project/negativeoutput"); //positiveoutput
        outPath.getFileSystem(conf).delete(outPath,true);

        // Put this file to distributed cache so
        // that it can be used by the mapper
//        DistributedCache.addCacheFile(new URI(args[3]), job.getConfiguration());
        job.addCacheFile(new URI("hdfs://localhost:9000/user/phamvanvung/project/negative.csv"));

        Configuration validationConf = new Configuration(false);
        ChainMapper.addMapper(job, TweetsValidationMapper.class, LongWritable.class,
                Text.class, LongWritable.class, Text.class, validationConf);

        Configuration ansConf = new Configuration(false);
        ChainMapper.addMapper(job, TweetSentimentMapper.class, LongWritable.class,
                Text.class, Text.class, IntWritable.class, ansConf);

        job.setMapperClass(ChainMapper.class);
        job.setCombinerClass(TweetSentimentReducer.class);
        job.setReducerClass(TweetSentimentReducer.class);

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(IntWritable.class);
        FileInputFormat.addInputPath(job, inPath);
        FileOutputFormat.setOutputPath(job, outPath);
        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}
