# Mongo Web Application
In this project, ICT2103 Team 26 created node CRUD application with Express and mongoDB.

#### To run npm you will need to install Node.js and place it in your system environment variables
```
https://nodejs.org/en/
```


#### To Run this project Clone it and install modules using
```
npm install
```

Create config.env file and create PORT and MONGO_URI Variable and specify value for mongo database configuration
Open server.js file and run
```
npm start
```

