const axios = require('axios');


exports.homeRoutes = (req, res) => {
    // Make a get request to /api/users
    axios.get('http://localhost:3000/api/industry')
        .then(function(response){
            res.render('index', { industry : response.data });
        })
        .catch(err =>{
            res.send(err);
        })

    
}

exports.add_user = (req, res) =>{
    res.render('add_user');
}

exports.update_user = (req, res) =>{
    axios.get('http://localhost:3000/api/industry', { params : { id : req.query.id }})
        .then(function(industrydata){
            res.render("update_user", { industry : industrydata.data})
        })
        .catch(err =>{
            res.send(err);
        })
}

exports.dashboard = (req,res,next) => {
    res.render('dashboard')
}