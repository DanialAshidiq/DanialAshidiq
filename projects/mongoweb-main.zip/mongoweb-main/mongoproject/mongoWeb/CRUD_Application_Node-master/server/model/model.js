const mongoose = require('mongoose');

var schema = new mongoose.Schema({
    industryName : {
        type: String
    },
    vacancy : String,
    year : String
})

const Industrydb = mongoose.model('industry', schema);

module.exports = Industrydb;