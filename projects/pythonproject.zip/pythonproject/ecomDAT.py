''' This is the GUI module using PySimpleGui'''
import ecomScraper
import re
import time
import numpy as np
import PySimpleGUI as sg
import pandas as pd
import ctypes
import matplotlib.pyplot as plt
from pandas import DataFrame
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from string import printable
from fuzzywuzzy import fuzz

# sets the view mode of the data frame
pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
pd.set_option('display.max_colwidth', None)


#GUI functions
def userInterfaceIni():
    """Summary or Description of the Function
    Main method to initiate the program and display GUI
    """    
    sg.theme("Light Blue")
    bgc = sg.theme_background_color()
    imagePath = r'..\pythonproject\iconpin.png'
    layout = [[sg.Canvas(size=(150, 70))],
              [sg.Image(imagePath, size=(60, 60), background_color=bgc), sg.Text('E-Commerce Analyzer', size=(20,0), font=('Helvitica', 23), justification='center')],
              [sg.Canvas(size=(150, 30))],
              [sg.Text('Welcome to our E-Commerce Analyzer Tool, please start by typing in the product you wish to search for and hit enter or click the "Search" button to begin.',size=(65, 5), font='Any 15', justification='left')],
              [sg.Text('What are you looking for?', size=(25, 1),font='Any 17', justification='center')],
              [sg.Input(size=(50, 30), enable_events=True, font='Any 15',key='-INPUT-', justification='center')],
              [sg.Button('Search', button_color="white on blue", size=(10, 2), bind_return_key=True), sg.Button('Exit', button_color="white on red", size=(10, 2))],
              [sg.Text('', size=(150, 3), justification='center')],
              [sg.Text('Currently supports only', size=(90, 0),font='Any 12', justification='left')],
              [sg.Text('www.qoo10.sg', size=(90, 0),font='Any 10', justification='left')],
              [sg.Text('www.shopee.sg', size=(90, 0),font='Any 10', justification='left')],
              [sg.Text('www.amazon.sg', size=(90, 0), font='Any 10', justification='left')]]

    window = sg.Window('E-commerce Data Analyzer Tool', layout,element_justification='c', size=(800, 600), finalize=True)
    window.size
    # Event Loop
    while True:
        event, values = window.read()
        if event in (sg.WIN_CLOSED, 'Exit'):  # always check for closed window
            break
        # if values['-INPUT-'] != '':  # if a keystroke entered in search field
        else:
            search = values['-INPUT-']
            # if a list item is chosen
            if event == '-LIST-' and len(values['-LIST-']):
                sg.popup('Selected ', values['-LIST-'])
            # search query validation
            if event == 'Search':
                if search is None:
                    continue
                if len(search) == 0:
                    ctypes.windll.user32.MessageBoxW(
                        0, "Please enter something", "Error", 0)
                    continue
                elif len(search) <= 3:
                    ctypes.windll.user32.MessageBoxW(
                        0, "Can't you type more than 3 words?", "Error", 0)
                    continue
                if (string_check(search) == False):
                    ctypes.windll.user32.MessageBoxW(
                        0, "Are you trying to be funny?", "Error", 0)
                    continue
                userquery = search.split()
                udf = webScrapIni(userquery) #calls webScrapIni function after valid search query input
                if event == 'Cancel':
                    break
                elif event != 'Cancel':
                    table_example(udf) #pass 
                else:
                    break
            if event == sg.WIN_CLOSED:
                break
    window.close()
    return None

def webScrapIni(fields):
    """Summary or Description of the Function
    Initiate ecomScraper method from our webscraper module

    Parameters:
    fields(str): search query input

    Returns:
    userqueryresult(object): calls userqueryresult function to proceed to clean data first then return a dataframe

    """
    meter = progressbar() #Loading bar as a visual cue for users
    meter[0].update_bar(0)
    list1 = ecomScraper.scrapQten(fields)
    meter[0].update_bar(3)
    list2 = ecomScraper.scrapShopee(fields)
    meter[0].update_bar(6)
    list3 = ecomScraper.scrapAmazon(fields)
    meter[0].update_bar(10)
    time.sleep(1)
    meter[1].close()
    return userqueryresult(list1, list2, list3, fields)

def userqueryresult(qooList, shopeeList, amazonList, fields=None):
    """Summary or Description of the Function
    Cleaning raw data collected before sending the data to generate a dataframe

    Parameters:
    qooList(list): qoo10 product data
    shopeeList(list): shopee product data
    amazonList(list): amazon product data
    fields(list): search query string

    Returns:
    df(object): returns a dataframe with the cleaned data
    """
    for idx1, a in enumerate(qooList):
        qooList[idx1] = remove_emoji(str(a))
        qooList[idx1] = clean_text(qooList[idx1])
    for idx2, b in enumerate(shopeeList):
        shopeeList[idx2] = remove_emoji(str(b))
        shopeeList[idx2] = clean_text(shopeeList[idx2])
    for idx3, c in enumerate(amazonList):
        amazonList[idx3] = remove_emoji(str(c))
        amazonList[idx3] = clean_text(amazonList[idx3])
    combinedlist = qooList + shopeeList + amazonList
    df = dataframe_generator(combinedlist, fields)
    return df

def dataframe_generator(cleanedinput, fields, source="not vaild", dtype="unknown"):
    """Summary or Description of the Function
    Cleaning raw data collected before sending the data to generate a dataframe

    Parameters:
    cleanedinput(list): cleaned data
    fields(list): search query string

    Optional Parameters:
    source(str):"not vaild" 
    dtype(str):"unknown"

    Returns:
    df(object): returns a dataframe created with the cleaned data
    """
    websitelist = []
    titlelist = []
    pricelist = []
    soldlist = []
    fuzzList = []
    searchField = " ".join(fields)

    for t in cleanedinput:
        # splits all the parameters(e.g ID,title,price) to be used below
        temp = t.split(",")
        for l in temp:
            # removes additional split fields that does not have required data
            if "ID:" not in l and "website:" not in l and "title:" not in l and "price:" not in l and "sold:" not in l:
                temp.remove(l)
        for idx, i in enumerate(temp):
            if "website:" in i:
                website = temp[idx].split(":")
                cleanedwebsite = website[1].strip()
                websitelist.append(cleanedwebsite)

            elif "title:" in i:
                titledata = temp[idx].split(":")
                cleanedtitle = titledata[1].strip()
                titlelist.append(cleanedtitle)
                
                fuzzList.append(fuzz.token_set_ratio(searchField.lower(), cleanedtitle.lower())) # calculate the fuzz score using title of product and searched query

            elif "price:" in i:
                pricedata = temp[idx].split(":")
                tempprice = str(pricedata[1])
                cleanedprice = ''
                if tempprice.count("S$") > 1:

                    if tempprice.find("."):
                        cleanedprice = tempprice[tempprice.find("S$") + 2: tempprice.find(
                            ".") + 3]  # filters out duplicate prices by taking the 1st occurrence of price,final price

                elif tempprice.count("S$") == 1:
                    cleanedprice = tempprice[tempprice.find("S$") + 2:]
                elif tempprice.count("S$") < 1:
                    cleanedprice = tempprice
                pricelist.append(cleanedprice)
            elif "sold:" in i:
                solddata = temp[idx].split(":")
                cleanedsold = solddata[1]
                soldlist.append(cleanedsold)

    data = {'Website': websitelist, 'Title': titlelist, 'Item_Price': pricelist, 'Sold': soldlist,'Fuzz_Score': fuzzList}  # sets dict with the values from list for dataframe input
    # uses the data ,creates a dataframe with the columns item id,title and item price
    ddf = DataFrame(data, columns=['Website', 'Title', 'Item_Price', 'Sold', 'Fuzz_Score'])
    # converts all values in the item price column into float
    ddf = ddf.astype({'Item_Price': 'float', 'Sold': 'int', 'Fuzz_Score': 'int'})
    return ddf

def table_example(tdf):
    """Summary or Description of the Function
    Create and display the dataframe using a PySimpleGUI table and the GUI to perform functions

    Parameters:
    tdf(object): dataframe generated

    Returns: None
    """
    sg.theme("Light Blue")
    data = tdf.values.tolist()
    heading = tdf.columns.tolist()
    website = ['Shopee', 'Amazon', 'Qoo10', 'All']
    website2 = ['Shopee', 'Amazon', 'Qoo10', 'None']
    sortby = ['Price Ascending', 'Price Descending', 'Most Sold', 'Fuzz Score']
    ftypes = ['csv', 'txt', 'xlsx']

    #layout designs for the table/functions GUI
    layout = [
        [sg.Table(values=data,
                  headings=heading,
                  display_row_numbers=True,
                  auto_size_columns=True,
                  justification="left",
                  def_col_width=300,
                  max_col_width=60,
                  enable_events=True,
                  num_rows=min(30, len(data)),
                  background_color='Light Grey',
                  font="Any 13",
                  key='-Table-'),
         # seperate buttons
         sg.VSeparator(),
         sg.Column([
             [sg.Text("FUNCTIONS", font="Any 20", size=(20, 0))],
             [sg.Text("The Fuzz Score represents how close of a match is the product from the searched query 0-100, where 100 being the best match.You can filter or sort the table.The statistics and extraction will be generated based on the current table data.", font="Any 12", size=(40, 0))],
             [sg.Combo(website, default_value="All", size=(12, len(website)), font="Any 12", readonly=True, key='-Website-')],
             [sg.Text("Compare with", font="Any 15")],
             [sg.Combo(website2, default_value="None", size=(12, len(website)), font="Any 12", readonly=True, key='-Website2-')],
             [sg.ReadFormButton('Filter', button_color="white on blue", size=(10, 1))],
             [sg.Text("----------------------------------",font="Any 20", size=(20, 1))],
             [sg.Text("Sort By", font="Any 15")],
             [sg.Combo(sortby, default_value="None", size=(15, len(sortby)), font="Any 12", readonly=True,key='-SortBy-'), sg.ReadFormButton('Sort', button_color="white on blue", size=(10, 1))],
             [sg.Text("Click Plot to generate statistics", font="Any 14"), sg.Button("Plot", button_color="white on blue", size=(10, 1))],
             [sg.Text("----------------------------------",font="Any 20", size=(20, 1))],
             [sg.Text("Select a filepath before exporting", font="Any 14")],
             [sg.In(size=(20, 1), font="Any 14", enable_events=True, readonly=True, key="-FOLDER-"),sg.FolderBrowse(button_color="white on blue", size=(10, 1), pad=(0, (5, 5)))],
             [sg.Combo(ftypes, default_value='csv', size=(7, len(ftypes)), font="Any 12", readonly=True,key='-FTYPES-'), sg.Button("Export", button_color="white on blue", size=(10, 1))],
             [sg.Text("----------------------------------",font="Any 20", size=(20, 1))],
             [sg.Button("Exit", button_color="white on red",size=(10, 1), pad=(0, (5, 0)))]
         ]),
         ]
    ]

    window = sg.Window('Product Analysis Overview', layout, auto_size_text=True, keep_on_top=False, grab_anywhere=False, size=(1600, 700),finalize=True)
    window['-Table-'].expand(True, True)

    #GUI events
    while True:
        event, values = window.read()
        if event in (sg.WIN_CLOSED, 'Exit'):
            break
        if event == 'Filter':
            queryDf('Website', values['-Website-'],values['-Website2-'], tdf, window['-Table-'])
        if event == 'Sort':
            tablelist = window['-Table-'].get()
            tldf = DataFrame(tablelist, columns=['Website', 'Title', 'Item_Price', 'Sold', 'Fuzz_Score'])
            if values['-SortBy-'] == 'Price Ascending':
                window['-Table-'].update(sort_ascending(tldf,'Item_Price').values.tolist())
            if values['-SortBy-'] == 'Price Descending':
                window['-Table-'].update(sort_descending(tldf,'Item_Price').values.tolist())
            if values['-SortBy-'] == 'Most Sold':
                window['-Table-'].update(sort_descending(tldf,'Sold').values.tolist())
            if values['-SortBy-'] == 'Fuzz Score':
                window['-Table-'].update(sort_descending(tldf,'Fuzz_Score').values.tolist())
        if event == 'Plot':
            tablelist = window['-Table-'].get()
            pldf = DataFrame(tablelist, columns=['Website', 'Title', 'Item_Price', 'Sold', 'Fuzz_Score'])
            bargraph(pldf)
        if event == 'Export':
            exportlist = window['-Table-'].get()
            edf = DataFrame(exportlist, columns=['Website', 'Title', 'Item_Price', 'Sold', 'Fuzz_Score'])
            export_table(edf, values['-FTYPES-'], values['-FOLDER-'])
    window.close()
    return None

def queryDf(searchCol1='None', searchTerm1='None', searchTerm2='None', qdf='None', tableobject='None'):
    """Summary or Description of the Function
    Filter function for the table
    """
    if searchTerm1 != 'All': # if searchTerm1 does not get All websites
        for c in qdf.columns:
            # checks the column title and finds the matching columns
            if searchCol1.lower() in c.lower():
                # search with 1 website parameter,and parameter 1 is not All
                if searchTerm1 != 'All' and searchTerm2 == 'None':
                    rdf = qdf[qdf[c].str.contains(searchTerm1, case=False)]
                    tableobject.update(values=rdf.values.tolist())
                    return rdf
                elif searchTerm2 != 'None':  # searches with 2 website parameter
                    if searchTerm1 != searchTerm2:
                        fdf = qdf[qdf[c].str.contains(searchTerm1, case=False)]
                        sdf = qdf[qdf[c].str.contains(searchTerm2, case=False)]
                        rdf = pd.concat([fdf, sdf], ignore_index=True)
                        tableobject.update(values=rdf.values.tolist())
                        return rdf
    elif searchTerm1 == 'All':    # for All websites stated in searchTerm1,searchTerm2 is ignored
        tableobject.update(values=qdf.values.tolist())

#plot graph functions
def bargraph(gdf):
    """Summary or Description of the Function
    Plot histogram and bar graph based on table data    
    """
    #close any exisiting pandas graph before generating new one
    plt.close()
    plt.close()
    # display a graph that has the number of items in all websites
    numitem = gdf['Website'].hist()
    numitem.set_ylabel("Number of Products")
    numitem.set_xlabel("Websites")
    boxplot = gdf.boxplot(column='Item_Price', by='Website',patch_artist=True, return_type='both')
    colors = ['y', 'r', '#FF8C00']
    for k, (ax, row) in boxplot.iteritems():
        ax.set_xlabel('')
        for i, box in enumerate(row['boxes']):
            box.set_facecolor(colors[i])
    return plt.show()

def draw_figure_w_toolbar(canvas, fig, canvas_toolbar):
    if canvas.children:
        for child in canvas.winfo_children():
            child.destroy()
    if canvas_toolbar.children:
        for child in canvas_toolbar.winfo_children():
            child.destroy()
    figure_canvas_agg = FigureCanvasTkAgg(fig, master=canvas)
    figure_canvas_agg.draw()
    toolbar = Toolbar(figure_canvas_agg, canvas_toolbar)
    toolbar.update()
    figure_canvas_agg.get_tk_widget().pack(side='right', fill='both', expand=1)

class Toolbar(NavigationToolbar2Tk):
    def __init__(self, *args, **kwargs):
        super(Toolbar, self).__init__(*args, **kwargs)

#export function
def export_table(edf, filetype, location):
    """Summary or Description of the Function
    Export current table data into csv,txt,xlxs

    Parameters:
    edf(object): dataframe 
    filetype(str): extension input selected from dropdown 
    location(path): directory path selected using PySimpleGUI browse widget
    """
    # export data to csv using dataframe:
    rlocation = location.replace("/", "\\")
    if rlocation != '':
        if filetype == "csv":
            edf.to_csv(rlocation + r"\productlist.csv", index=False)
            ctypes.windll.user32.MessageBoxW(
                0, "Export as .csv Success", "Success", 0)
        # export data to txt using dataframe:
        elif filetype == "txt":
            np.savetxt(rlocation + r"\productlist.txt",
                       edf.values, fmt="%s", delimiter=",")
            ctypes.windll.user32.MessageBoxW(
                0, "Export as .txt Success", "Success", 0)
        # export data to xlsx using dataframe(pip install openpyxl may be needed)
        elif filetype == "xlsx":
            edf.to_excel(rlocation + r"\productlist.xlsx", index=False)
            ctypes.windll.user32.MessageBoxW(
                0, "Export as .xlsx Success", "Success", 0)
        else:
            ctypes.windll.user32.MessageBoxW(
                0, "Uh Oh! Something went wrong during extraction.", "Error", 0)
    else:
        ctypes.windll.user32.MessageBoxW(
            0, "Please select a location to save the file.", "Error", 0)

#helper functionss
def string_check(s):
    s.strip()
    ns = re.sub('[!@#$%^&*():+<>?\|=-_/]', '', s)
    qs = re.sub('[" "]', '', ns)
    qs = re.search('[a-zA-Z]', qs)

    if set(s).difference(printable) or ns != s or qs == None:
        return False
    else:
        return True

def remove_emoji(string):
    emoji_pattern = re.compile("["
                               u"\U0001F600-\U0001F64F"  # emoticons
                               u"\U0001F300-\U0001F5FF"  # symbols & pictographs
                               u"\U0001F680-\U0001F6FF"  # transport & map symbols
                               u"\U0001F1E0-\U0001F1FF"  # flags (iOS)
                               u"\U00002500-\U00002BEF"  # chinese char
                               u"\U00002702-\U000027B0"
                               u"\U00002702-\U000027B0"
                               u"\U000024C2-\U0001F251"
                               u"\U0001f926-\U0001f937"
                               u"\U00010000-\U0010ffff"
                               u"\u2640-\u2642"
                               u"\u2600-\u2B55"
                               u"\u200d"
                               u"\u23cf"
                               u"\u23e9"
                               u"\u231a"
                               u"\ufe0f"  # dingbats
                               u"\u3030"
                               u"\u00A9-\u23FA"  # ver 1.1 ,6.0 and 7.0 utf 8 emoji
                               "]+", flags=re.UNICODE)
    return emoji_pattern.sub(r'', string)

def clean_text(filteredtext):
    preclean = filteredtext.replace("{", "") \
        .replace("}", "") \
        .replace("}", "") \
        .replace("'", "") \
        .replace("/", "") \
        .replace("", "")
    return preclean

def sort_ascending(qdf, col):
    qdf = qdf.sort_values(by=col)
    return qdf

def sort_descending(qdf, col):
    qdf = qdf.sort_values(by=col, ascending=False)
    return qdf

def progressbar():
    layout = [[sg.Text('Scraping..... Please wait for a few seconds')],
              [sg.ProgressBar(max_value=10, orientation='h', size=(30, 20), key='progbar')]]
    window = sg.Window('Process', layout, finalize=True)
    pbar = window['progbar']
    return pbar, window

# MAIN CODE STARTS HERE
userInterfaceIni()
