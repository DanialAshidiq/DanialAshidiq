''' This is the webscraper module currently supports only qoo10,shopee,amazon.sg '''
import requests
import re
import time
import random
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from bs4 import BeautifulSoup

#relative path for chromedriver requirement for selenium
PATH = r"..\pythonproject\chromedriver.exe"

#options to configure webdriver
options = webdriver.ChromeOptions()
options.add_argument('headless')
options.add_argument('window-size=1920x1080')
options.add_argument('start-maximized')
options.add_argument('disable-gpu')
options.add_argument('--disable-extensions')

def GET_UA():
    #useragent random generator to simulate different browsers when sending requests to avoid getting timeout
    uastrings = [
        "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2125.111 Safari/537.36",
        "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10) AppleWebKit/600.1.25 (KHTML, like Gecko) Version/8.0 Safari/600.1.25",
        "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:33.0) Gecko/20100101 Firefox/33.0",
        "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2125.111 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2125.111 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.1.17 (KHTML, like Gecko) Version/7.1 Safari/537.85.10",
        "Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko",
        "Mozilla/5.0 (Windows NT 6.3; WOW64; rv:33.0) Gecko/20100101 Firefox/33.0",
        "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2125.104 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36"]
    return random.choice(uastrings)

def scrapQten(fields):
    """Summary or Description of the Function
    Scraping products off qoo10 based on a search, using request to generate the html content and beautifulsoup to locate product details using html class tags. 

    Parameters:
    fields(str): search query input

    Returns:
    qooList(list): list containing all products scraped from qoo10

    """
    qooList = []
    qooItems = []
    query = '+'.join(fields)
    url = 'https://www.qoo10.sg/s/?keyword=%s' % (query)
    try:
        r = requests.get(url, headers={'User-Agent': GET_UA()})
    except requests.exceptions.RequestException as e :
        print("qoo10 request exeception : " + e)
        return qooList
    try:
        soup = BeautifulSoup(r.content, 'html.parser')
        qtenList = soup.find_all("tbody")
        for table in qtenList:
            for row in table.find_all('tr'):
                qooItems.append(row)

        for item in qooItems:

            myProducts = item.find("div", {"class": "sbj"})
            myProductsPrc = item.find("div", {"class": "prc"})
            myProductsSold = item.find("a", {"class": "lnk_rv"})

            if (myProducts is None or myProductsPrc is None):
                continue
            else:
                myProducts = myProducts.get_text(strip=True)
                myProductsPrc = re.sub('[\," "]', '', myProductsPrc.get_text(strip=True))
                if (myProductsSold is not None and intCheck(myProductsSold.text.strip()) == False):
                    myProductsSold = re.findall('\d+', myProductsSold.get_text(strip=True))[0]
                    myProductsSold = re.sub('[\$,A-Z,a-z]', '', myProductsSold)
                else:
                    myProductsSold = 0
                prod = {
                    'website': 'qoo10',
                    'title': myProducts,
                    'price': myProductsPrc,
                    'sold': int(myProductsSold)
                }

                qooList.append(prod)
    except (ConnectionError, Exception) as e:
        print(e)
        return qooList #return whatever products scraped before exceptions hits
    return qooList


def scrapShopee(fields):
    """Summary or Description of the Function
    Scraping products off qoo10 based on a search, using selenium with webdriver to create an env to access the website and sending keystrokes to load the product content and 
    finally using beautifulsoup to locate product details using html class tags.

    Parameters:
    fields(str): search query input

    Returns:
    shopeeList(list): list containing all products scraped from shopee

    """
    shopeeList = []
    shopeeItems = []
    query = '%20'.join(fields)
    url = "https://shopee.sg/search?keyword=%s&page=0" % (query)
    try:
        driver = webdriver.Chrome(PATH, options=options)
        driver.get(url)

        check = WebDriverWait(driver, 15).until(EC.presence_of_element_located((By.CSS_SELECTOR, 'div[data-sqe=item] a[data-sqe=link]')))
    except (ConnectionError, Exception) as e:
        print(e)
        return shopeeList

    if check is not None:
        i = 0
        while i < 5:
            check.send_keys(Keys.PAGE_DOWN)
            time.sleep(0.3)
            i += 1
        if i == 5:
            html = driver.page_source
            soup = BeautifulSoup(html, 'html.parser')
            shopeeItems = soup.find(class_='shopee-search-item-result__items')
    else:
        driver.quit()
        return shopeeList

    for p in shopeeItems:
        myProducts = p.find(class_="O6wiAW")
        myProductsPrc = p.find(class_="_341bF0")
        myProductsSold = p.find(class_="_18SLBt")

        if (myProducts is None or myProductsPrc is None):
            continue
        else:
            myProducts = myProducts.get_text(strip=True)
            myProductsPrc = re.sub('[\$,A-Z,a-z," "]', '', myProductsPrc.get_text(strip=True))
            if (myProductsSold is None or intCheck(myProductsSold.text.strip()) == False):
                myProductsSold = 0
            else:
                myProductsSold = re.sub('[\$,A-Z,a-z," "]', '', myProductsSold.text.strip())
            prod = {
                'website': "shopee",
                'title': myProducts,
                'price': myProductsPrc,
                'sold': int(myProductsSold)
            }
            shopeeList.append(prod)

    return shopeeList


def scrapAmazon(fields):
    """Summary or Description of the Function
    Scraping products off amazon.sg based on a search, using request to generate the html content and beautifulsoup to locate product details using html class tags. 

    Parameters:
    fields(str): search query input

    Returns:
    amazonList(list): list containing all products scraped from amazonsg

    """
    amazonList = []
    amazonItems = []
    query = '+'.join(fields)
    url = "https://www.amazon.sg/s?k=%s&page=1" % (query)
    try:
        r = requests.get(url, headers={'User-Agent': GET_UA()})
    except requests.exceptions.RequestException as e :
        print("amazon request exeception : " + e)
        return amazonList

    soup = BeautifulSoup(r.content, 'html.parser')

    amazonListItem = soup.find_all('div', {'class': 's-main-slot s-result-list s-search-results sg-row'})
    for table in amazonListItem:
        for row in table.find_all('div', {'class': 'a-section a-spacing-medium'}):
            amazonItems.append(row)

    for item in amazonItems:
        myProduct = item.find("span", {"class": "a-size-base-plus a-color-base a-text-normal"})
        myProductPrc = item.find("span", {"class": "a-price-whole"})
        myProductPrcFrac = item.find("span", {"class": "a-price-fraction"})
        myProductSold = item.find("span", {"class": "a-size-base", "dir": "auto"})

        if (myProduct is None or myProductPrc is None):
            continue
        else:
            myProduct = myProduct.text.strip()
            myProductPrc = str(myProductPrc.text.strip()) + str(myProductPrcFrac.text.strip())
            if (myProductSold is None or intCheck(myProductSold.text.strip()) == False):
                myProductSold = 0
            else:
                myProductSold = re.sub('[$,A-Z,a-z," "]', '', myProductSold.text.strip())

            prod = {
                'website': 'amazon.sg',
                'title': myProduct,
                'price': myProductPrc,
                'sold': int(myProductSold)
            }
        amazonList.append(prod)

    return amazonList

def intCheck(s):
    try:
        s = re.sub('[\$,A-Z,a-z," "]', '', s)
        int(s)
        return True
    except ValueError:
        return False
