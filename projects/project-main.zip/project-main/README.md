**Checkout master branch**
- git checkout master

**Create and checkout branch**
- git checkout -b <branchname>

**Push your branch to GitHub**
- git push -u origin <branchname>

*Basic workflow*:
  - Checkout your branch
  - git checkout <branchname>

Code and test your code

Stage your changes to the branch (best practice to add the files that you modified only)
- git add <file name>

**Commit your changes**
- git commit -m “<commit message>”
or
- git commit Press enter and type the summary and description for the commit. Then press esc and type :wq

**Push your changes to Github**
- git push

**Get updates from master branch to your own branch**:
- Check out master branch
- git checkout master

**Pull updates from remote master branch to local master branch**
- git pull

**Change back to your branch**
- git checkout <branchname>

**Merge master branch code to your branch**
- git merge master

**Once your feature is completed, merge it to master branch**:
- You can create a pull request in Github to merge your branch to master branch

OR
**Checkout master branch**
- git checkout master

**Merge your branch to master branch**
- git merge <branchname>

**Push merged code to master branch in Github**
- git push

Note: Best practice to commit your changes regularly
